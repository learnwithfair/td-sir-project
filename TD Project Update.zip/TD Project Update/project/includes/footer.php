    <!-- Footer -->
    <footer class="text-center" style="background-color: rgb(32 38 51)">
        <!-- Grid container -->
        <div class="container pt-5 text-white-50">
            <!-- Section: Form -->
            <section class="py-4">
                <form action="">
                    <!--Grid row-->
                    <div class="row d-flex justify-content-center">
                        <!--Grid column-->
                        <div class="col-auto">
                            <p class="pt-2">
                                <strong>Sign up for our newsletter</strong>
                            </p>
                        </div>
                        <!--Grid column-->

                        <!--Grid column-->
                        <div class="col-md-5 col-12">
                            <!-- Email input -->
                            <div class="form-outline mb-4">
                                <input type="email" id="form5Example2" class="form-control" style="border: 2px solid" />
                                <label class="form-label text-white" for="form5Example2">Email address</label>
                            </div>
                        </div>
                        <!--Grid column-->

                        <!--Grid column-->
                        <div class="col-auto">
                            <!-- Submit button -->
                            <button type="submit" class="btn btn-primary mb-4">
                                Subscribe
                            </button>
                        </div>
                        <!--Grid column-->
                    </div>
                    <!--Grid row-->
                </form>
            </section>
            <!-- Section: Form -->

            <!-- Section: Links -->
            <section class="">
                <!--Grid row-->
                <div class="row">
                    <!--Grid column-->
                    <div class="col-lg-4 col-md-6 mb-4 mb-md-0 text-start">
                        <h5 class="text-uppercase">Academics & Admission</h5>

                        <ul class="list-unstyled mb-0">
                            <li>
                                <a href="#!" class="text-white-50">Link 1</a>
                            </li>
                            <li>
                                <a href="#!" class="text-white-50">Link 2</a>
                            </li>
                            <li>
                                <a href="#!" class="text-white-50">Link 3</a>
                            </li>
                            <li>
                                <a href="#!" class="text-white-50">Link 4</a>
                            </li>
                        </ul>
                    </div>
                    <!--Grid column-->

                    <!--Grid column-->
                    <div class="col-lg-4 col-md-6 mb-4 mb-md-0 text-start">
                        <h5 class="text-uppercase">Important Links</h5>

                        <ul class="list-unstyled mb-0">
                            <li>
                                <a href="#!" class="text-white-50">Link 1</a>
                            </li>
                            <li>
                                <a href="#!" class="text-white-50">Link 2</a>
                            </li>
                            <li>
                                <a href="#!" class="text-white-50">Link 3</a>
                            </li>
                            <li>
                                <a href="#!" class="text-white-50">Link 4</a>
                            </li>
                        </ul>
                    </div>
                    <!--Grid column-->

                    <!--Grid column-->
                    <div class="col-lg-4 col-md-6 mb-4 mb-md-0 text-start">
                        <h5 class="text-uppercase">Contact US</h5>

                        <div style="width: 350px">
                            Pabna University of Science and Technology,Pabna Registrar
                            (Current Charge),
                            <p>
                                <i class="fa fa-phone" aria-hidden="true"></i> +8802588842742
                            </p>
                            <p>
                                <i class="fa fa-envelope" aria-hidden="true"></i>
                                bijon16@yahoo.com
                            </p>
                            <p>
                                <i class="fa fa-envelope" aria-hidden="true"></i>
                                registraroffice@pust.ac.bd
                            </p>
                            <p>
                                <a href="https://play.google.com/store/apps/details?id=pust.ice.krypton.pustcontacts"
                                    target="_blank" rel="noopener noreferrer"
                                    style="border: none; text-decoration: none"><img height="80px"
                                        src="https://www.pust.ac.bd/includes/images/play_store.png" /></a>
                            </p>
                        </div>
                    </div>
                    <!--Grid column-->
                </div>
                <!--Grid row-->
            </section>
            <!-- Section: Links -->
            <?php include "social_link.php";?>
        </div>
        <!-- Grid container -->

        <!-- Copyright -->
        <div class="text-center p-3" style="background-color: rgba(0, 0, 0, 0.2)">
            © 2022 Copyright:
            <a class="text-white-50" href="https://www.facebook.com/mdrahatulrabbi/">Rahatul Rabbi & Shoaib Ahmad</a>
        </div>
        <!-- Copyright -->
    </footer>
    <!-- Footer -->