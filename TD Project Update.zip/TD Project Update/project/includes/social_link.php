 <!-- Section: Social media -->
 <section class="mb-4">
     <!-- Facebook -->
     <a class="btn btn-primary btn-floating m-1" style="background-color: #3b5998" href="#!" role="button"><i
             class="fab fa-facebook-f"></i></a>

     <!-- Twitter -->
     <a class="btn btn-primary btn-floating m-1" style="background-color: #55acee" href="#!" role="button"><i
             class="fab fa-twitter"></i></a>

     <!-- Linkedin -->
     <a class="btn btn-primary btn-floating m-1" style="background-color: #0082ca" href="#!" role="button"><i
             class="fab fa-linkedin-in"></i></a>
     <!-- Github -->
     <a class="btn btn-primary btn-floating m-1" style="background-color: #333333" href="#!" role="button"><i
             class="fab fa-github"></i></a>
 </section>
 <!-- Section: Social media -->