<?php $menu_item = $obj1->display_menu_item();?>
<!-- Header -->


<header class="">
    <nav class="navbar navbar-expand-lg navbar-light bg-white fixed-top">
        <div class="container-fluid mx-5">
            <a class="navbar-brand" href="index.php">
                <img src="./assets/img/pust.png" alt="" height="60px">
            </a>
            <button class="navbar-toggler" type="button" data-mdb-toggle="collapse" data-mdb-target="#navbarExample01"
                aria-controls="navbarExample01" aria-expanded="false" aria-label="Toggle navigation">
                <i class="fas fa-bars"></i>
            </button>
            <div class="collapse navbar-collapse" id="navbarExample01">

                <!-- ######################################### -->
                <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
                    <?php
                        // Menu display from category as reverse within 5 items .

                        $uri = $_SERVER['PHP_SELF'];

                        // Outputs: URI
                        session_start();
                        while ( $item = mysqli_fetch_assoc( $menu_item ) ) {

                            if ( isset( $_SESSION['user_roll'] ) && $item['menu_title'] == "Log In" ) {
                                continue;
                            } elseif ( !( isset( $_SESSION['user_roll'] ) ) && $item['menu_title'] == "Profile" ) {
                                continue;
                            } else {
                                if ( $uri == "/project/" ) {
                                    $uri = $uri . "index.php";
                                }
                            if ( $uri == "/project/" . $item['menu_link'] ) {?>
                    <li class="nav-item active">
                        <a class="nav-link" aria-current="page" href="<?php echo $item['menu_link']; ?>"><b
                                style="text-transform:uppercase;"><?php echo $item['menu_title']; ?></b>
                            <!-- <span class="sr-only">(current)</span> -->
                        </a>
                    </li>
                    <?php
                            } else {

                                    ?>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo $item['menu_link']; ?>"><b
                                style="text-transform:uppercase;"><?php echo $item['menu_title']; ?></b></a>
                    </li>
                    <?php
                            }
                                }

                        }?>
                </ul>


            </div>
        </div>
    </nav>