<?php include_once "includes/head.php"?>
<?php
    if ( isset( $_POST['login_btn'] ) ) {
        $login_mgs = $obj1->user_login( $_POST );
    }

?>


<body>
    <?php include_once "includes/header.php"?>

    <?php
       session_start();
       if ( isset( $_SESSION['user_roll'] ) ) {
           header( "location:profile.php" );

       } else {
       ?>

    <div class="card form_style mx-auto ">
        <div class="card-body p-5">
            <h3 class="card-title text-center pb-5">Login Here</h3>
            <form class="needs-validation" novalidate action="" method="POST">
                <div class="form-outline mb-4">
                    <input type="number" class="form-control" id="validationCustom01" value="" name="non_r_roll"
                        required />
                    <label for="validationCustom01" class="form-label">Roll Number</label>
                    <div class="valid-feedback">Looks good!</div>
                </div>

                <div class="form-outline mb-4">
                    <input type="number" class="form-control" id="validationCustom02" name="non_r_reg" value=""
                        required />
                    <label for="validationCustom02" class="form-label">Reg number</label>
                    <div class="valid-feedback">Looks good!</div>
                    <div class="invalid-feedback">Please provide a valid roll</div>
                </div>

                <div class="col-12 text-end">
                    <button class="btn btn-primary" type="submit" name="login_btn">Login</button>
                </div>
            </form>
        </div>

        <div class="text-center">
            <p>Create an account? <a href="registration_form.php">Register</a></p>

        </div>
    </div>


    <?php
    }

?>



    <!-- footer -->
    <?php include_once "includes/footer.php"?>
    <!-- Footer -->


    <?php include_once 'includes/script.php';?>
</body>

</html>