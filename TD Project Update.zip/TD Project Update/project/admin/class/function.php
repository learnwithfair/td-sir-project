<?php
class std_list_project {
    private $conn;
    public function __CONSTRUCT() {
        $bdhost     = "localhost";
        $dbuser     = "root";
        $dbpassword = "";
        $dbname     = "student_info";
        $this->conn = mysqli_connect( $bdhost, $dbuser, $dbpassword, $dbname );
        if ( !( $this->conn ) ) {
            die( "Database connection Error!!" );
        }
    }

    // Checking Login Info
    public function getAdminData( $data ) {
        $admin_check    = 0;
        $email          = $data['admin_email'];
        $password       = md5( $data['admin_password'] );
        $get_query      = "SELECT * FROM admin_info";
        $all_admin_info = mysqli_query( $this->conn, $get_query );
        // checking query admin table
        while ( $match_data = mysqli_fetch_assoc( $all_admin_info ) ) {
            if ( $email == $match_data['admin_email'] && $password == $match_data['admin_password'] ) {
                $admin_check              = 1;
                $_SESSION['admin_id']     = $match_data['admin_id'];
                $_SESSION['admin_name']   = $match_data['admin_name'];
                $_SESSION['admin_email']  = $match_data['admin_email'];
                $_SESSION['admin_status'] = $match_data['admin_status'];
                header( "location:template.php" );
                break;
            }
        }
        if ( $admin_check == 0 ) {
            echo "<script>alert('Email or Password is incorrect!!')</script>";
        }
    }

    // Logout Section
    public function logout_info() {
        unset( $_SESSION['admin_id'] );
        unset( $_SESSION['admin_name'] );
        unset( $_SESSION['admin_email'] );
        unset( $_SESSION['admin_status'] );
        header( "location: index.php" );
    }

    // Display Admin Officer
    public function admin_officer() {
        $display_admin_officer_query = "SELECT * FROM admin_info WHERE admin_status='Admin Officer'";
        $display_admin_officer_list  = mysqli_query( $this->conn, $display_admin_officer_query );
        $admin_officer_name          = mysqli_fetch_assoc( $display_admin_officer_list );
        if ( isset( $admin_officer_name ) ) {
            return $admin_officer_name['admin_email'];
        }
    }

    // Display Admin List
    public function display_subadmin_list() {
        $display_subadmin_list_query = "SELECT * FROM admin_info ORDER BY admin_status ASC";
        $display_subadmin_list       = mysqli_query( $this->conn, $display_subadmin_list_query );
        if ( isset( $display_subadmin_list ) ) {
            return $display_subadmin_list;
        }
    }

    // Delete Sub Admin List
    public function subadmin_dlt( $id ) {
        $dlt_subadmin_list_query = "DELETE FROM admin_info WHERE admin_id=$id";
        $dlt_subadmin_list       = mysqli_query( $this->conn, $dlt_subadmin_list_query );
        if ( isset( $dlt_subadmin_list ) ) {
            return "Sub Admin deleted Successfully.";
        } else {
            return "Sub Admin delete Unsuccessful.";
        }
    }

    // Add Subadmin
    public function add_subadmin( $data ) {
        $admin_name          = $data['admin_name'];
        $admin_email         = $data['admin_email'];
        $password            = $data['admin_password'];
        $admin_status        = $data['admin_status'];
        $admin_password      = md5( $password );
        $admin_display_query = "SELECT * FROM admin_info WHERE admin_email='$admin_email'";
        $admins              = mysqli_query( $this->conn, $admin_display_query );
        if ( mysqli_fetch_assoc( $admins ) ) {
            return "This Admin Already Registered!!";
        } else {
            $add_admin_query = "INSERT INTO admin_info(admin_name,admin_email,admin_password,admin_start,admin_status) VALUES('$admin_name','$admin_email','$admin_password',now(),'$admin_status')";
            $return_mgs      = mysqli_query( $this->conn, $add_admin_query );
            if ( $return_mgs ) {
                return "Admin Added Successfully.";
            } else {
                return "Admin Add Unsuccessful.";
            }
        }
    }

    // Display Residential Info
    // public function residential_info() {
    //     $display_r_query = "SELECT * FROM residential_info ORDER BY r_roll ASC";
    //     $display_r_info  = mysqli_query( $this->conn, $display_r_query );
    //     if ( isset( $display_r_info ) ) {
    //         return $display_r_info;
    //     }
    // }
    // Display Residential Info
    public function residential_info() {
        $display_r_query = "SELECT * FROM nonresidential_info WHERE non_r_status='Residential' ORDER BY non_r_roll ASC";
        $display_r_info  = mysqli_query( $this->conn, $display_r_query );
        if ( isset( $display_r_info ) ) {
            return $display_r_info;
        }
    }

    // Display Pagi Residential Info
    public function pagi_residential_info( $pegi_start, $pegi_end ) {
        $display_r_query = "SELECT * FROM nonresidential_info WHERE non_r_status='Residential' ORDER BY non_r_roll ASC LIMIT $pegi_start,$pegi_end";
        $display_r_info  = mysqli_query( $this->conn, $display_r_query );
        if ( isset( $display_r_info ) ) {
            return $display_r_info;
        }
    }

    // Display Residential Unique Info
    public function r_unique_info( $r_roll ) {
        $display_r_query = "SELECT * FROM residential_info WHERE r_roll=$r_roll ORDER BY r_year ASC";
        $display_r_info  = mysqli_query( $this->conn, $display_r_query );
        if ( isset( $display_r_info ) ) {
            return $display_r_info;
        }
    }

    // Update Paid Status
    public function r_status_update( $data ) {

        $u_id   = $data['u_r_id'];
        $months = "";
        if ( empty( $data['r_jan'] ) ) {
            $r_jan = "Unpaid";
        } else {
            $r_jan = "Paid";
            if ( $data['r_jan'] == "Paid" ) {
                $months = $months . "JAN ";
            }

        }
        if ( empty( $data['r_feb'] ) ) {
            $r_feb = "Unpaid";
        } else {
            $r_feb = "Paid";
            if ( $data['r_feb'] == "Paid" ) {
                $months = $months . "FEB ";
            }
        }
        if ( empty( $data['r_mar'] ) ) {
            $r_mar = "Unpaid";
        } else {
            $r_mar = "Paid";
            if ( $data['r_mar'] == "Paid" ) {
                $months = $months . "MAR ";
            }

        }
        if ( empty( $data['r_apr'] ) ) {
            $r_apr = "Unpaid";
        } else {
            $r_apr = "Paid";
            if ( $data['r_apr'] == "Paid" ) {
                $months = $months . "APR ";
            }

        }
        if ( empty( $data['r_may'] ) ) {
            $r_may = "Unpaid";
        } else {
            $r_may = "Paid";
            if ( $data['r_may'] == "Paid" ) {
                $months = $months . "MAY ";
            }

        }
        if ( empty( $data['r_jun'] ) ) {
            $r_jun = "Unpaid";
        } else {
            $r_jun = "Paid";
            if ( $data['r_jun'] == "Paid" ) {
                $months = $months . "JUN ";
            }

        }
        if ( empty( $data['r_jul'] ) ) {
            $r_jul = "Unpaid";
        } else {
            $r_jul = "Paid";
            if ( $data['r_jul'] == "Paid" ) {
                $months = $months . "JUL ";
            }

        }
        if ( empty( $data['r_aug'] ) ) {
            $r_aug = "Unpaid";
        } else {
            $r_aug = "Paid";
            if ( $data['r_aug'] == "Paid" ) {
                $months = $months . "AUG ";
            }

        }
        if ( empty( $data['r_sep'] ) ) {
            $r_sep = "Unpaid";
        } else {
            $r_sep = "Paid";
            if ( $data['r_sep'] == "Paid" ) {
                $months = $months . "SEP ";
            }

        }
        if ( empty( $data['r_oct'] ) ) {
            $r_oct = "Unpaid";
        } else {
            $r_oct = "Paid";
            if ( $data['r_oct'] == "Paid" ) {
                $months = $months . "OCT ";
            }

        }
        if ( empty( $data['r_nov'] ) ) {
            $r_nov = "Unpaid";
        } else {
            $r_nov = "Paid";
            if ( $data['r_nov'] == "Paid" ) {
                $months = $months . "NOV ";
            }

        }
        if ( empty( $data['r_dec'] ) ) {
            $r_dec = "Unpaid";
        } else {
            $r_dec = "Paid";
            if ( $data['r_dec'] == "Paid" ) {
                $months = $months . "DEC ";
            }

        }
        $r_paid_query    = "UPDATE residential_info SET r_jan='$r_jan',r_feb='$r_feb',r_mar='$r_mar',r_apr='$r_apr', r_may='$r_may',r_jun='$r_jun',r_jul='$r_jul',r_aug='$r_aug',r_sep='$r_sep',r_oct='$r_oct',r_nov='$r_nov',r_dec='$r_dec' WHERE r_id=$u_id";
        $return_paid_mgs = mysqli_query( $this->conn, $r_paid_query );
        if ( $return_paid_mgs ) {
            //Put History
            if ( !empty( $months ) ) {
                $r_roll_query    = "SELECT * FROM residential_info WHERE r_id=$u_id";
                $r_roll_data     = mysqli_query( $this->conn, $r_roll_query );
                $ph_roll_display = mysqli_fetch_assoc( $r_roll_data );
                if ( $ph_roll_display ) {
                    $ph_roll         = $ph_roll_display['r_roll'];
                    $ph_year         = $ph_roll_display['r_year'];
                    $r_display_query = "SELECT * FROM nonresidential_info WHERE non_r_roll=$ph_roll";
                    $r_display_data  = mysqli_query( $this->conn, $r_display_query );
                    $ph_info         = mysqli_fetch_assoc( $r_display_data );
                    if ( $ph_info ) {
                        $ph_name         = $ph_info['non_r_name'];
                        $ph_roll         = $ph_info['non_r_roll'];
                        $ph_reg          = $ph_info['non_r_reg'];
                        $ph_submitted    = $_SESSION['admin_name'];
                        $months          = $months . "-" . $ph_year;
                        $r_history_query = "INSERT INTO payment_history(ph_name,ph_roll,ph_reg,ph_month,ph_date,ph_submitted) VALUES('$ph_name',$ph_roll,$ph_reg,'$months',now(),'$ph_submitted')";
                        $r_history_mgs   = mysqli_query( $this->conn, $r_history_query );
                        if ( $r_history_mgs ) {
                            return "Data Updated successfully.";
                        }
                    }
                }
            }

        } else {
            return "Data cann't Updated successfully.";
        }

    }

    // Change Paid Status
    public function r_payment_change( $data ) {

        $u_id   = $data['u_r_id'];
        $months = "";
        if ( empty( $data['r_jan'] ) ) {
            $r_jan = "Paid";
        } else {
            $r_jan = "Unpaid";
            if ( $data['r_jan'] == "Unpaid" ) {
                $months = $months . "JAN ";
            }

        }
        if ( empty( $data['r_feb'] ) ) {
            $r_feb = "Paid";
        } else {
            $r_feb = "Unpaid";
            if ( $data['r_feb'] == "Unpaid" ) {
                $months = $months . "FEB ";
            }
        }
        if ( empty( $data['r_mar'] ) ) {
            $r_mar = "Paid";
        } else {
            $r_mar = "Unpaid";
            if ( $data['r_mar'] == "Unpaid" ) {
                $months = $months . "MAR ";
            }

        }
        if ( empty( $data['r_apr'] ) ) {
            $r_apr = "Paid";
        } else {
            $r_apr = "Unpaid";
            if ( $data['r_apr'] == "Unpaid" ) {
                $months = $months . "APR ";
            }

        }
        if ( empty( $data['r_may'] ) ) {
            $r_may = "Paid";
        } else {
            $r_may = "Unpaid";
            if ( $data['r_may'] == "Unpaid" ) {
                $months = $months . "MAY ";
            }

        }
        if ( empty( $data['r_jun'] ) ) {
            $r_jun = "Paid";
        } else {
            $r_jun = "Unpaid";
            if ( $data['r_jun'] == "Unpaid" ) {
                $months = $months . "JUN ";
            }

        }
        if ( empty( $data['r_jul'] ) ) {
            $r_jul = "Paid";
        } else {
            $r_jul = "Unpaid";
            if ( $data['r_jul'] == "Unpaid" ) {
                $months = $months . "JUL ";
            }

        }
        if ( empty( $data['r_aug'] ) ) {
            $r_aug = "Paid";
        } else {
            $r_aug = "Unpaid";
            if ( $data['r_aug'] == "Unpaid" ) {
                $months = $months . "AUG ";
            }

        }
        if ( empty( $data['r_sep'] ) ) {
            $r_sep = "Paid";
        } else {
            $r_sep = "Unpaid";
            if ( $data['r_sep'] == "Unpaid" ) {
                $months = $months . "SEP ";
            }

        }
        if ( empty( $data['r_oct'] ) ) {
            $r_oct = "Paid";
        } else {
            $r_oct = "Unpaid";
            if ( $data['r_oct'] == "Unpaid" ) {
                $months = $months . "OCT ";
            }

        }
        if ( empty( $data['r_nov'] ) ) {
            $r_nov = "Paid";
        } else {
            $r_nov = "Unpaid";
            if ( $data['r_nov'] == "Unpaid" ) {
                $months = $months . "NOV ";
            }

        }
        if ( empty( $data['r_dec'] ) ) {
            $r_dec = "Paid";
        } else {
            $r_dec = "Unpaid";
            if ( $data['r_dec'] == "Unpaid" ) {
                $months = $months . "DEC ";
            }

        }

        $r_paid_query    = "UPDATE residential_info SET r_jan='$r_jan',r_feb='$r_feb',r_mar='$r_mar',r_apr='$r_apr', r_may='$r_may',r_jun='$r_jun',r_jul='$r_jul',r_aug='$r_aug',r_sep='$r_sep',r_oct='$r_oct',r_nov='$r_nov',r_dec='$r_dec' WHERE r_id=$u_id";
        $return_paid_mgs = mysqli_query( $this->conn, $r_paid_query );
        if ( $return_paid_mgs ) {
            //Put History
            if ( !empty( $months ) ) {

                $r_roll_query    = "SELECT * FROM residential_info WHERE r_id=$u_id";
                $r_roll_data     = mysqli_query( $this->conn, $r_roll_query );
                $ph_roll_display = mysqli_fetch_assoc( $r_roll_data );
                if ( $ph_roll_display ) {
                    $ph_roll         = $ph_roll_display['r_roll'];
                    $ph_year         = $ph_roll_display['r_year'];
                    $r_display_query = "SELECT * FROM nonresidential_info WHERE non_r_roll=$ph_roll";
                    $r_display_data  = mysqli_query( $this->conn, $r_display_query );
                    $ph_info         = mysqli_fetch_assoc( $r_display_data );
                    if ( $ph_info ) {
                        $ph_name         = $ph_info['non_r_name'];
                        $ph_roll         = $ph_info['non_r_roll'];
                        $ph_reg          = $ph_info['non_r_reg'];
                        $ph_submitted    = $_SESSION['admin_name'];
                        $months          = $months . "-" . $ph_year . "</br>Changed";
                        $r_history_query = "INSERT INTO payment_history(ph_name,ph_roll,ph_reg,ph_month,ph_date,ph_submitted) VALUES('$ph_name',$ph_roll,$ph_reg,'$months',now(),'$ph_submitted')";
                        $r_history_mgs   = mysqli_query( $this->conn, $r_history_query );
                        if ( $r_history_mgs ) {
                            return "Data Updated successfully.";
                        }
                    }
                }
            }

        } else {
            return "Data cann't Updated successfully.";
        }

    }

    // Completed Paid Status
    public function u_r_paid_status( $id ) {
        $r_paid_query    = "UPDATE residential_info SET r_status='Completed' WHERE r_id=$id";
        $return_paid_mgs = mysqli_query( $this->conn, $r_paid_query );
        if ( $return_paid_mgs ) {
            return "Data Updated successfully.";
        } else {
            return "Data cann't Updated successfully.";
        }

    }

    // Display Residential Info by search
    public function display_r_data_by_search( $search_bar_data ) {
        $info1 = $search_bar_data['r_search_text'];
        $info  = trim( $info1 );
        if ( $info ) {
            $r_display_query = "SELECT * FROM nonresidential_info WHERE ((non_r_roll LIKE '%$info%'&&non_r_status='Residential')||(non_r_reg LIKE '%$info%'&&non_r_status='Residential')||(non_r_rm LIKE '%$info%'&&non_r_status='Residential')) ORDER BY non_r_roll ASC";
            $data            = mysqli_query( $this->conn, $r_display_query );

        } else {
            $data = $info;

        }
        return $data;
    }

    // Display Non Residential Info
    public function non_residential_info() {
        $display_non_r_query = "SELECT * FROM nonresidential_info WHERE non_r_status='Nonresidential' ORDER BY non_r_roll ASC";
        $display_non_r_info  = mysqli_query( $this->conn, $display_non_r_query );
        if ( isset( $display_non_r_info ) ) {
            return $display_non_r_info;
        }
    }

    // Display Residential Info
    public function display_residential_info() {
        $display_r_query = "SELECT * FROM nonresidential_info WHERE non_r_status='Residential' ORDER BY non_r_roll ASC";
        $display_r_info  = mysqli_query( $this->conn, $display_r_query );
        if ( isset( $display_r_info ) ) {
            return $display_r_info;
        }
    }

    // Display Residential Info by Id
    public function display_residential_info_by_id( $id ) {
        $display_r_query = "SELECT * FROM nonresidential_info WHERE non_r_id=$id";
        $display_r_info  = mysqli_query( $this->conn, $display_r_query );
        $result          = mysqli_fetch_assoc( $display_r_info );
        if ( $result ) {
            return $result;
        }
    }

    // Delete Non Residential Info
    public function non_r_delete( $id ) {
        // Get Image Name
        $search_r_img        = "SELECT * FROM nonresidential_info WHERE non_r_id=$id";
        $search_r_img_result = mysqli_query( $this->conn, $search_r_img );
        $img_data            = mysqli_fetch_assoc( $search_r_img_result );

        if ( isset( $img_data ) ) {
            $non_r_dlt_query = "DELETE FROM nonresidential_info WHERE non_r_id=$id";
            $non_r_dlt_mgs   = mysqli_query( $this->conn, $non_r_dlt_query );
            if ( isset( $non_r_dlt_mgs ) ) {
                $img = $img_data['non_r_img'];
                unlink( "../uploads/$img" );

                // Delete Residential Data
                $dlt_roll    = $img_data['non_r_roll'];
                $r_dlt_query = "DELETE FROM residential_info WHERE r_roll=$dlt_roll";
                $r_dlt_mgs   = mysqli_query( $this->conn, $r_dlt_query );
                return "Deleted Successfully.";

            } else {
                return "Delete Unsuccessful.";
            }
        }
    }

    // Approve Non Residential Info
    public function non_r_approve( $id ) {
        $non_r_approve_query      = "UPDATE nonresidential_info SET non_r_status='Residential' WHERE non_r_id=$id";
        $return_non_r_approve_mgs = mysqli_query( $this->conn, $non_r_approve_query );
        if ( $return_non_r_approve_mgs ) {
            return "Approve successfully.";
        } else {
            return "Approve Unsuccessfull.";
        }

    }

    // Update Residential Info
    public function r_update( $data ) {
        $u_r_id          = $data['u_r_id'];
        $u_r_name        = $data['u_r_name'];
        $u_r_roll        = $data['u_r_roll'];
        $u_r_reg         = $data['u_r_reg'];
        $u_r_session     = $data['u_r_session'];
        $u_r_dept        = $data['u_r_dept'];
        $u_r_rm          = $data['u_r_rm'];
        $u_r_birth       = $data['u_r_birth'];
        $u_r_email       = $data['u_r_email'];
        $u_r_fname       = $data['u_r_fname'];
        $u_r_mname       = $data['u_r_mname'];
        $u_r_pre_address = $data['u_r_pre_address'];
        $u_r_per_address = $data['u_r_per_address'];

        // Get Roll From Non Residential Info
        $r_find_roll_query      = "SELECT * FROM nonresidential_info WHERE non_r_id=$u_r_id";
        $return_r_find_roll_mgs = mysqli_query( $this->conn, $r_find_roll_query );
        $get_roll               = mysqli_fetch_assoc( $return_r_find_roll_mgs );
        $u_roll                 = $get_roll['non_r_roll'];

        // Update Non Residential Info
        $non_r_update_query      = "UPDATE nonresidential_info SET non_r_name='$u_r_name',non_r_roll=$u_r_roll,non_r_reg=$u_r_reg,non_r_session=$u_r_session,non_r_dept='$u_r_dept',non_r_rm=$u_r_rm,non_r_birth='$u_r_birth',non_r_email='$u_r_email',non_r_fname='$u_r_fname',non_r_mname='$u_r_mname',non_r_pre_address='$u_r_pre_address',non_r_per_address='$u_r_per_address' WHERE non_r_id=$u_r_id";
        $return_non_r_update_mgs = mysqli_query( $this->conn, $non_r_update_query );
        if ( $return_non_r_update_mgs ) {

            // Select Residential Info
            $r_select_query      = "SELECT * FROM residential_info WHERE r_roll=$u_roll";
            $return_r_select_mgs = mysqli_query( $this->conn, $r_select_query );
            $r_ids               = array();

            // Get Residential ID
            while ( $r_id_info = mysqli_fetch_assoc( $return_r_select_mgs ) ) {
                array_push( $r_ids, $r_id_info['r_id'] );

            }
            $r_year = $u_r_session;
            // Update Residential Info
            for ( $i = 0; $i < count( $r_ids ); $i++ ) {
                $r_year++;
                $r_id                = $r_ids[$i];
                $r_update_query      = "UPDATE residential_info SET r_roll=$u_r_roll,r_reg=$u_r_reg,r_year=$r_year,r_rm=$u_r_rm,r_start=$u_r_session WHERE r_id=$r_id";
                $return_r_update_mgs = mysqli_query( $this->conn, $r_update_query );
            }
            return "Successfully Update.";

        } else {
            return "Update Unsuccessfull.";
        }

    }

    // Put in the Residential Info
    public function put_r_info( $id ) {
        $display_r_query = "SELECT * FROM nonresidential_info WHERE non_r_id=$id";
        $r_info          = mysqli_query( $this->conn, $display_r_query );

        while ( $r_unique_info = mysqli_fetch_assoc( $r_info ) ) {
            $r_roll = $r_unique_info['non_r_roll'];
            $r_reg  = $r_unique_info['non_r_reg'];
            $r_rm   = $r_unique_info['non_r_rm'];
            $r_year = $r_unique_info['non_r_session'];
            for ( $year = ( $r_year + 1 ); $year <= ( $r_year + 5 ); $year++ ) {
                $r_paid_query    = "INSERT INTO residential_info(r_roll,r_reg,r_year,r_rm,r_jan,r_feb,r_mar,r_apr,r_may,r_jun,r_jul,r_aug,r_sep,r_oct,r_nov,r_dec,r_start,r_status) VALUES($r_roll,$r_reg,$year,$r_rm,'Unpaid','Unpaid','Unpaid','Unpaid','Unpaid','Unpaid','Unpaid','Unpaid','Unpaid','Unpaid','Unpaid','Unpaid',$r_year,'Uncompleted')";
                $return_paid_mgs = mysqli_query( $this->conn, $r_paid_query );
            }

        }
    }

    // Add Year in the Residential Info
    public function r_add_year( $data ) {
        $roll                = $data['add_year_roll'];
        $display_non_r_query = "SELECT * FROM nonresidential_info WHERE non_r_roll=$roll";
        $non_r_info          = mysqli_query( $this->conn, $display_non_r_query );
        while ( $non_r_data = mysqli_fetch_assoc( $non_r_info ) ) {

            $r_roll = $non_r_data['non_r_roll'];
            $r_reg  = $non_r_data['non_r_reg'];
            $r_year = $non_r_data['non_r_session'];
            $r_rm   = $non_r_data['non_r_rm'];
        }
        $display_r_query = "SELECT * FROM residential_info WHERE r_roll=$roll";
        $r_info          = mysqli_query( $this->conn, $display_r_query );
        $year_count      = mysqli_num_rows( $r_info );
        $year            = $r_year + $year_count + 1;

        $r_paid_query    = "INSERT INTO residential_info(r_roll,r_reg,r_year,r_rm,r_jan,r_feb,r_mar,r_apr,r_may,r_jun,r_jul,r_aug,r_sep,r_oct,r_nov,r_dec,r_start,r_status) VALUES($r_roll,$r_reg,$year,$r_rm,'Unpaid','Unpaid','Unpaid','Unpaid','Unpaid','Unpaid','Unpaid','Unpaid','Unpaid','Unpaid','Unpaid','Unpaid',$r_year,'Uncompleted')";
        $return_paid_mgs = mysqli_query( $this->conn, $r_paid_query );

    }

    // Display Contact Message
    public function display_message() {
        $display_message_query      = "SELECT * FROM message_info ORDER BY message_id DESC";
        $return_display_content_mgs = mysqli_query( $this->conn, $display_message_query );
        if ( isset( $return_display_content_mgs ) ) {
            return $return_display_content_mgs;
        } else {
            die( "Data is not found!!" );
        }

    }

    // Delete Contact Message
    public function mgs_dlt( $id ) {
        $mgs_dlt_query = "DELETE FROM message_info WHERE message_id=$id";
        $result2       = mysqli_query( $this->conn, $mgs_dlt_query );

        if ( $result2 ) {
            return "Deleted Successfully.";

        } else {
            return "Delete Unsuccessfull.";
        }
    }

    // Display Payment History
    public function display_history() {
        $display_history_query      = "SELECT * FROM payment_history ORDER BY ph_id DESC";
        $return_display_history_mgs = mysqli_query( $this->conn, $display_history_query );
        if ( isset( $return_display_history_mgs ) ) {
            return $return_display_history_mgs;
        } else {
            die( "History is not found!!" );
        }

    }

    // Delete Payment History
    public function delete_history( $display_items ) {
        $display_history_query      = "SELECT * FROM payment_history";
        $return_display_history_mgs = mysqli_query( $this->conn, $display_history_query );
        $id                         = array();
        while ( $info = mysqli_fetch_assoc( $return_display_history_mgs ) ) {
            array_push( $id, $info['ph_id'] );
        }

        $start        = $id[0];
        $end          = $id[count( $id ) - ( $display_items + 1 )];
        $ph_dlt_query = "DELETE FROM payment_history WHERE ph_id BETWEEN $start AND $end";
        $result       = mysqli_query( $this->conn, $ph_dlt_query );

        if ( isset( $result ) ) {
            return "Succesfully Deleted";
        }

    }

    // Display Payment Query
    public function display_payment_query( $data ) {
        $from_months = str_split( $data['from_date'], 1 );
        $from_month  = (int) ( $from_months[5] . $from_months[6] );
        $from_year   = (int) ( str_split( $data['from_date'], 4 )[0] );

        $to_months = str_split( $data['to_date'], 1 );
        $to_month  = (int) ( $to_months[5] . $to_months[6] );
        $to_year   = (int) ( str_split( $data['to_date'], 4 )[0] );

        if ( $from_year != $to_year ) {
            echo "<script>alert('Please Select Same Year !!')</script>";
        } elseif ( $from_month > $to_month ) {
            echo "<script>alert('Please Select Valid Month !!')</script>";
        } else {
            $display_payment_query = "SELECT * FROM residential_info WHERE r_year = $from_year ORDER BY r_rm ASC";
            $return_payment_mgs    = mysqli_query( $this->conn, $display_payment_query );
            if ( isset( $return_payment_mgs ) ) {
                return $return_payment_mgs;
            } else {
                die( "No Result found!!" );
            }

        }

    }

    function non_r_info_by_roll( $roll ) {
        $r_display_query = "SELECT * FROM nonresidential_info WHERE non_r_roll=$roll";
        $r_display_data  = mysqli_query( $this->conn, $r_display_query );
        $r_info          = mysqli_fetch_assoc( $r_display_data );
        return $r_info;
    }

    // public function update_product( $data ) {

    //     $u_id                 = $data['u_id'];
    //     $u_product_id         = $data['u_product_id'];
    //     $u_product_name       = $data['u_product_name'];
    //     $u_product_des        = $data['u_product_des'];
    //     $u_product_stock      = $data['u_product_stock'];
    //     $u_product_price      = $data['u_product_price'];
    //     $u_product_price_name = $data['u_product_price_name'];

    //     $u_product_cat    = $data['u_product_cat'];
    //     $u_product_status = $data['u_product_status'];

    //     $u_product_query   = "UPDATE add_product SET product_id=$u_product_id,product_name='$u_product_name',product_des='$u_product_des',product_stock=$u_product_stock,product_price= $u_product_price, product_price_name='$u_product_price_name',product_cat='$u_product_cat',product_status='$u_product_status' WHERE ID=$u_id";
    //     $return_update_mgs = mysqli_query( $this->conn1, $u_product_query );
    //     if ( $return_update_mgs ) {
    //         return "Data Updated successfully.";
    //     } else {
    //         return "Data cann't Updated successfully.";
    //     }

    // }

    // public function display_product_datas() {
    //     $product_display_query = "SELECT * FROM add_product ORDER BY product_id ASC";
    //     $data                  = mysqli_query( $this->conn1, $product_display_query );
    //     return $data;

    // }

    // public function display_prduct_datas_by_id( $id ) {
    //     $product_display_by_id_query = "SELECT * FROM add_product WHERE product_id=$id";
    //     $data                        = mysqli_query( $this->conn1, $product_display_by_id_query );
    //     $product_data                = mysqli_fetch_assoc( $data );
    //     if ( isset( $product_data ) ) {
    //         return $product_data;
    //     }

    // }

    // public function display_product_img() {
    //     $display_product_img_query = "SELECT * FROM add_product_img ORDER BY product_id ASC";
    //     $product_img_data          = mysqli_query( $this->conn1, $display_product_img_query );

    //     if ( isset( $product_img_data ) ) {
    //         return $product_img_data;
    //     }

    // }

    // public function display_product_img_by_id( $id ) {
    //     $display_product_img_query = "SELECT * FROM add_product_img WHERE product_id=$id";
    //     $product_img_data          = mysqli_query( $this->conn1, $display_product_img_query );

    //     if ( isset( $product_img_data ) ) {
    //         return $product_img_data;
    //     } else {
    //         return "Something went wrong";
    //     }

    // }

    // public function product_img_change_by_id( $data ) {
    //     $id                       = $data['u_product_img_id'];
    //     $product_img_name         = $_FILES['u_product_img']['name'];
    //     $product_img_tmp_name     = $_FILES['u_product_img']['tmp_name'];
    //     $product_img_update_query = "UPDATE add_product_img SET product_img='$product_img_name' WHERE img_id=$id";
    //     $result                   = mysqli_query( $this->conn1, $product_img_update_query );
    //     if ( $result ) {
    //         move_uploaded_file( $product_img_tmp_name, "../uploads/" . $product_img_name );
    //         return "Image Changed Successfully.";
    //     }
    // }

    // public function product_img_dlt_by_id( $id ) {

    //     $search_product_img        = "SELECT * FROM add_product_img WHERE img_id=$id";
    //     $search_product_img_result = mysqli_query( $this->conn1, $search_product_img );
    //     $img_datas                 = mysqli_fetch_assoc( $search_product_img_result );

    //     $product_img_dlt_query = "DELETE FROM add_product_img WHERE img_id=$id";
    //     $result                = mysqli_query( $this->conn1, $product_img_dlt_query );
    //     if ( $result ) {
    //         $img = $img_datas['product_img'];
    //         unlink( "../uploads/$img" );
    //         return $img_datas['product_id'];
    //     } else {
    //         return "Data is not deleted.";
    //     }
    // }

    // public function product_img_all_dlt_by_id( $id ) {

    //     $search_product_img        = "SELECT * FROM add_product_img WHERE product_id=$id";
    //     $search_product_img_result = mysqli_query( $this->conn1, $search_product_img );

    //     $product_img_dlt_query = "DELETE FROM add_product_img WHERE product_id=$id";
    //     $result                = mysqli_query( $this->conn1, $product_img_dlt_query );
    //     if ( $result ) {
    //         while ( $image = mysqli_fetch_assoc( $search_product_img_result ) ) {
    //             $img = $image['product_img'];
    //             unlink( "../uploads/$img" );
    //         }

    //         return -789;
    //     } else {
    //         return "Image is not deleted.";
    //     }
    // }

    // public function product_dlt( $id ) {

    //     $search_product_img        = "SELECT * FROM add_product_img WHERE product_id=$id";
    //     $search_product_img_result = mysqli_query( $this->conn1, $search_product_img );

    //     $product_dlt_query = "DELETE FROM add_product WHERE product_id=$id";
    //     $result2           = mysqli_query( $this->conn1, $product_dlt_query );

    //     $product_img_dlt_query = "DELETE FROM add_product_img WHERE product_id=$id";
    //     $result1               = mysqli_query( $this->conn1, $product_img_dlt_query );

    //     if ( $result2 ) {

    //         if ( $result1 ) {
    //             while ( $image = mysqli_fetch_assoc( $search_product_img_result ) ) {
    //                 $img = $image['product_img'];
    //                 unlink( "../uploads/$img" );
    //             }

    //             return "Product deleted Successfully.";
    //         }

    //     } else {
    //         return "Product is not deleted.";
    //     }
    // }

    // public function display_message() {
    //     $display_message_query      = "SELECT * FROM message_info ORDER BY message_id DESC";
    //     $return_display_content_mgs = mysqli_query( $this->conn1, $display_message_query );
    //     if ( isset( $return_display_content_mgs ) ) {
    //         return $return_display_content_mgs;
    //     } else {
    //         die( "Data is not found!!" );
    //     }

    // }

    // public function mgs_dlt( $id ) {
    //     $mgs_dlt_query = "DELETE FROM message_info WHERE message_id=$id";
    //     $result2           = mysqli_query( $this->conn1, $mgs_dlt_query );

    //     if ( $result2 ) {
    //             return "Product deleted Successfully.";

    //     } else {
    //         return "Product is not deleted.";
    //     }
    // }

}
