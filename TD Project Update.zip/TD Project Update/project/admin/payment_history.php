<?php
$view = "payment_history";
include 'template.php';

?>