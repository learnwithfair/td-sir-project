<?php
$view = "add_sub_admin";
include 'template.php';

?>