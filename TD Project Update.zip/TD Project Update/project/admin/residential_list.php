<?php
$view = "residential_list";
include 'template.php';

?>