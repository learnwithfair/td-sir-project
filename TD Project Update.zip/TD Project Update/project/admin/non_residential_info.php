<?php
$view = "non_residential_info";
include 'template.php';

?>