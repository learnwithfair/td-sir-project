<div id="layoutSidenav_nav">
    <nav class="sb-sidenav accordion sb-sidenav-dark" id="sidenavAccordion">
        <div class="sb-sidenav-menu">
            <div class="nav">
                <div class="sb-sidenav-menu-heading">Core</div>
                <a class="nav-link" href="dashboard.php">
                    <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                    Dashboard
                </a>

                <?php if ( $_SESSION['admin_status'] == "Admin Officer" ) {?>
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseadmin"
                    aria-expanded="false" aria-controls="collapseadmin">
                    <div class="sb-nav-link-icon"><i class="fas fa-user fa-fw"></i></div>
                    Admin
                    <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                </a>
                <div class="collapse" id="collapseadmin" aria-labelledby="headingOne" data-parent="#sidenavAccordion">
                    <nav class="sb-sidenav-menu-nested nav">

                        <a class="nav-link" href="add_sub_admin.php"><i class="fa fa-angle-double-right"></i> &nbsp;Add
                            Admin</a>
                        <a class="nav-link" href="manage_sub_admin.php"><i class="fa fa-angle-double-right"></i>
                            &nbsp;Manage Admin</a>
                    </nav>
                </div>
                <?php } else {?>
                <a class="nav-link" href="sub_admin_list.php">
                    <div class="sb-nav-link-icon"><i class="fas fa-user fa-fw"></i></div>
                    Admin List
                </a>
                <?php }?>
                <a class="nav-link" href="non_residential_info.php">
                    <div class="sb-nav-link-icon"><i class="fa fa-info-circle"></i></div>
                    Non Residential Info
                </a>
                <!-- <a class="nav-link" href="residential_list.php">
                    <div class="sb-nav-link-icon"><i class="far fa-check-circle"></i></div>
                    Residential List
                </a>
                <a class="nav-link" href="residential_info.php">
                    <div class="sb-nav-link-icon"><i class="fa fa-info-circle"></i></div>
                    Residential Info
                </a> -->
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseresidential"
                    aria-expanded="false" aria-controls="collapseresidential">
                    <div class="sb-nav-link-icon"><i class="fa fa-info-circle"></i></div>
                    Residential
                    <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                </a>
                <div class="collapse" id="collapseresidential" aria-labelledby="headingOne"
                    data-parent="#sidenavAccordion">
                    <nav class="sb-sidenav-menu-nested nav">
                        <a class="nav-link" href="residential_list.php"><i class="fa fa-angle-double-right"></i>
                            &nbsp;Residential List</a>
                        <a class="nav-link" href="residential_info.php"><i class="fa fa-angle-double-right"></i>
                            &nbsp;Residential Info</a>

                    </nav>
                </div>

                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapsepayment"
                    aria-expanded="false" aria-controls="collapsepayment">
                    <div class="sb-nav-link-icon"><i class="far fa-check-circle"></i></div>
                    Payment
                    <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                </a>
                <div class="collapse" id="collapsepayment" aria-labelledby="headingOne" data-parent="#sidenavAccordion">
                    <nav class="sb-sidenav-menu-nested nav">
                        <a class="nav-link" href="payment_query.php"><i class="fa fa-angle-double-right"></i>
                            &nbsp;Payment Query</a>
                        <a class="nav-link" href="payment_change.php"><i class="fa fa-angle-double-right"></i>
                            &nbsp;Payment Change</a>
                        <a class="nav-link" href="payment_history.php"><i class="fa fa-angle-double-right"></i>
                            &nbsp;Payment History</a>
                    </nav>
                </div>
                <a class="nav-link" href="manage_message.php">
                    <div class="sb-nav-link-icon"><i class="fa fa-envelope"></i></div>
                    Messages
                </a>
            </div>
        </div>
        <div class="sb-sidenav-footer">
            <div class="small">Logged in as:</div>
            <?php echo $_SESSION['admin_name']; ?>
        </div>
    </nav>
</div>