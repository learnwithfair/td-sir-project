<?php if ( $_SESSION['admin_status'] == "Admin Officer" ) {?>
<?php

        if ( isset( $_GET['status'] ) ) {
            if ( $_GET['status'] == "subadmin_dlt" ) {
                $dlt_id  = $_GET['id'];
                $dlt_mgs = $obj->subadmin_dlt( $dlt_id );
            }
        }
        $data = $obj->display_subadmin_list();
    ?>

<br>
<div class="card mb-4">
    <div class="card-header">


        <h5> <i class="fas fa-table mr-1"></i> Manage Admin:</h5>
        <h6 style="color:red;"><?php if ( isset( $dlt_mgs ) ) {
                                       echo $dlt_mgs;
                                   }?></h6>
        <div></div>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-bordered vertical_align" id="dataTable" width="100%" cellspacing="0">
                <thead>
                    <tr>
                        <th>S/N</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Password</th>
                        <th>Start Date</th>
                        <th>Status</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tfoot>
                    <tr>
                        <th>S/N</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Password</th>
                        <th>Start Date</th>
                        <th>Status</th>
                        <th>Action</th>
                    </tr>
                </tfoot>
                <tbody>
                    <?php

                            $cout          = 1;
                            $admin_officer = 1;
                            $admin_1       = 1;
                            $admin_2       = 1;
                            $admin_3       = 1;

                        while ( $info = mysqli_fetch_assoc( $data ) ) {?>
                    <tr>
                        <td><?php echo $cout++; ?></td>
                        <td><?php echo $info['admin_name']; ?></td>
                        <td>
                            <a href="mailto:<?php echo $info['admin_email']; ?>">
                                <?php echo $info['admin_email']; ?>
                            </a>
                        </td>
                        <td><?php echo $info['admin_password']; ?></td>
                        <td><?php echo $info['admin_start']; ?></td>
                        <td><?php
                            if ( $info['admin_status'] == "Admin Officer" ) {?>
                            <b style="color:red;">*</b>
                            <?php echo $info['admin_status'] . " - (" . $admin_officer . ")";
                                        $admin_officer++;
                                    } elseif ( $info['admin_status'] == "Admin-1" ) {
                                        echo $info['admin_status'] . " (" . $admin_1 . ")";
                                        $admin_1++;
                                    } elseif ( $info['admin_status'] == "Admin-2" ) {
                                        echo $info['admin_status'] . " (" . $admin_2 . ")";
                                        $admin_2++;
                                    } elseif ( $info['admin_status'] == "Admin-3" ) {
                                        echo $info['admin_status'] . " (" . $admin_3 . ")";
                                        $admin_3++;
                                    } else {
                                        echo $info['admin_status'];
                                    }
                                    ?>
                        </td>

                        <td method='post'>
                            <a href="?status=subadmin_dlt&&id=<?php echo $info['admin_id']; ?>" class="btn btn-danger"
                                name="subadmin_dlt_btn">Delete</a>
                        </td>
                    </tr>
                    <?php }?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php } else {
        echo "<h4 style = 'color:red; text-align:center; margin:25%;'>Not Accessible</h4>";
}
?>