<?php if ( $_SESSION['admin_status'] == "Admin Officer" || $_SESSION['admin_status'] == "Admin-1" ) {?>
<?php
    if ( isset( $_POST['add_subadmin'] ) ) {
        $add_subadmin_return_mgs = $obj->add_subadmin( $_POST );
    }
    ?>
<br>

<div class="card mb-4" style="padding:10px">
    <div class="card-header">
        <h5> <i class="fas fa-user-plus"></i> Add Admin:</h5>
        <h6 style="color:red;"><?php if ( isset( $add_subadmin_return_mgs ) ) {echo $add_subadmin_return_mgs;}?></h6>
        <div></div>
    </div>
    <form action="" method='POST' class='form' enctype="multipart/form-data">
        <br>
        <div class="row">
            <div class="form-group col-md-6 col-sm-12">
                <input type="text" name='admin_name' $id="admin_name" class='form-control py4' placeholder='Enter Name'
                    required>

            </div>
            <div class="form-group col-md-6 col-sm-12">
                <input type="email" name='admin_email' $id="admin_email" class='form-control py4'
                    placeholder='Enter E-mail' required>
            </div>
        </div>
        <div class="row">
            <div class="form-group col-md-6 col-sm-12">
                <input type="password" name='admin_password' $id="admin_password" class='form-control py4'
                    placeholder='Enter Password' required>
            </div>
            <div class="form-group col-md-6 col-sm-12">
                <select name="admin_status" id="admin_status" class='form-control py4' required>
                    <option value="">Select</option>
                    <option value="Admin Officer">Admin Officer</option>
                    <option value="Admin-1">Admin-1</option>
                    <option value="Admin-2">Admin-2</option>
                    <option value="Admin-3">Admin-3</option>
                </select>
            </div>
        </div>


        <br>
        <div class="row">
            <div class="form-group col-md-2" style="margin:0 auto">
                <input type="submit" name='add_subadmin' value="Add Admin" class='form-control btn btn-secondary'>

            </div>
        </div>
        </br>
    </form>
</div>
<?php } else {
        echo "<h4 style = 'color:red; text-align:center; margin:25%;'>Not Accessible</h4>";
}
?>