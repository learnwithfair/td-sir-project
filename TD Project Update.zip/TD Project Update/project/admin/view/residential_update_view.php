<?php if ( $_SESSION['admin_status'] == "Admin Officer" ) {?>
<link href="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/4.2.0/mdb.min.css" rel="stylesheet" />
<?php

        if ( isset( $_GET['status'] ) ) {
            if ( $_GET['status'] == "r_update" ) {
                $r_update_id = $_GET['id'];
                $r_info      = $obj->display_residential_info_by_id( $r_update_id );

            }
        }
        if ( isset( $_POST['r_update_btn'] ) ) {
            $update_result = $obj->r_update( $_POST );
        }

    ?>

<br>

<div class="card mb-4" style="padding:10px">
    <div class="card-header">
        <h5> <i class="fa fa-edit"></i> Update Residential Info:</h5>
        <h6 style="color:red;"><?php if ( isset( $update_result ) ) {echo ( $update_result );}?></h6>
        <div></div>
        <hr>
    </div>
    <form class="needs-validation" action="" method="POST" novalidate enctype="multipart/form-data">
        <!-- name -->
        <input type="hidden" value="<?php if ( isset( $r_update_id ) ) {echo $r_update_id;}?>" name="u_r_id">
        <div class="form-outline mb-4">
            <input type="text" class="form-control" id="validationCustom01" name="u_r_name"
                value="<?php echo $r_info['non_r_name']; ?>" required />
            <label for="validationCustom01" class="form-label">Name</label>
            <div class="valid-feedback">Looks good!</div>
            <div class="invalid-feedback">Please provide a valid name.</div>
        </div>
        <!-- roll and registration -->
        <div class="row mb-4">
            <div class="col">
                <div class="form-outline">
                    <input type="number" id="form6Example1" class="form-control" id="validationCustom01"
                        value="<?php echo $r_info['non_r_roll']; ?>" name="u_r_roll" required />
                    <label class="form-label" for="form6Example1">Roll number</label>
                    <div class="valid-feedback">Looks good!</div>
                    <div class="invalid-feedback">Please provide...</div>
                </div>
            </div>
            <div class="col">
                <div class="form-outline">
                    <input type="number" id="form6Example2" class="form-control" id="validationCustom01"
                        value="<?php echo $r_info['non_r_reg']; ?>" name="u_r_reg" required />
                    <label class="form-label" for="form6Example2">Registration number</label>
                    <div class="valid-feedback">Looks good!</div>
                    <div class="invalid-feedback">Please provide...</div>
                </div>
            </div>
        </div>
        <!-- options -->

        <div class="form-group">
            <select name="u_r_session" id="u_r_session" class='form-control py4' required>

                <option value="">Select Session</option>
                <?php for ( $i = 2010; $i < 2041; $i++ ) {?>
                <option value="<?php echo $i; ?>" <?php if ( $i == $r_info['non_r_session'] ) {?> selected<?php }?>>
                    <?php echo $i . " - " . $i + 1; ?></option>
                <?php }?>
            </select>

        </div>

        <div class="row mb-4">
            <div class="col">
                <div class="form-outline">
                    <input type="number" id="form6Example1" class="form-control" id="validationCustom01"
                        value="<?php echo $r_info['non_r_rm']; ?>" name="u_r_rm" />
                    <label class="form-label" for="form6Example1">Room No</label>
                    <div class="valid-feedback">Looks good!</div>
                    <div class="invalid-feedback">Please provide...</div>
                </div>
            </div>
            <div class="col">
                <div class="form-outline">
                    <input type="date" id="form6Example2" class="form-control" id="validationCustom01" name="u_r_birth"
                        value="<?php echo $r_info['non_r_birth']; ?>" required />
                    <label class="form-label" for="form6Example2">Date of Birth</label>
                    <div class="valid-feedback">Looks good!</div>
                    <div class="invalid-feedback">Please provide...</div>
                </div>
            </div>
        </div>
        <?php
            $departments = array( "CSE", "EEE", "ICE", "CE", "EECE", "URP", "GE", "Architectural", "Pharmacy", "Public Add", "STAT", "MATH", "Chemistry", "Physics", "SW", "HBS", "THM", "BBA", "ECO", "English", "Bangla" );
            ?>
        <div class="form-group">
            <select name="u_r_dept" id="u_r_dept" class='form-control py4' required>
                <option value="">Select Department</option>

                <?php
                    for ( $i = 0; $i < count( $departments ); $i++ ) {
                        ?>
                <option value="<?php echo $departments[$i]; ?>"
                    <?php if ( $departments[$i] == $r_info['non_r_dept'] ) {?> selected<?php }?>>
                    <?php echo $departments[$i]; ?></option>
                <?php
                    }

                    ?>


            </select>
        </div>




        <div class="row mb-4">
            <div class="col">
                <div class="form-outline">
                    <input type="text" id="form6Example1" class="form-control" id="validationCustom01"
                        value="<?php echo $r_info['non_r_fname']; ?>" name="u_r_fname" required />
                    <label class="form-label" for="form6Example1">Father's name</label>
                    <div class="valid-feedback">Looks good!</div>
                    <div class="invalid-feedback">Please provide...</div>
                </div>
            </div>
            <div class="col">
                <div class="form-outline">
                    <input type="text" id="form6Example2" class="form-control" id="validationCustom01" name="u_r_mname"
                        value="<?php echo $r_info['non_r_mname']; ?>" required />
                    <label class="form-label" for="form6Example2">Mother's name</label>
                    <div class="valid-feedback">Looks good!</div>
                    <div class="invalid-feedback">Please provide...</div>
                </div>
            </div>
        </div>

        <div class="form-outline mb-4">
            <input type="text" class="form-control" id="validationCustom01" name="u_r_email"
                value="<?php echo $r_info['non_r_email']; ?>" required />
            <label for="validationCustom01" class="form-label">E-mail</label>
            <div class="valid-feedback">Looks good!</div>
            <div class="invalid-feedback">Please provide a valid email.</div>
        </div>



        <div class="row mb-4">
            <div class="col">
                <div class="form-outline">
                    <input type="text" class="form-control" id="validationCustom02" name="u_r_pre_address"
                        value="<?php echo $r_info['non_r_pre_address']; ?>" />
                    <label for="validationCustom02" class="form-label">Present address</label>
                    <div class="valid-feedback">Looks good!</div>
                    <div class="invalid-feedback">Please provide a valid address</div>
                </div>
            </div>
            <div class="col">
                <div class="form-outline">
                    <input type="text" class="form-control" id="validationCustom02" name="u_r_per_address"
                        value="<?php echo $r_info['non_r_per_address']; ?>" required />
                    <label for="validationCustom02" class="form-label">Permanent address</label>
                    <div class="valid-feedback">Looks good!</div>
                    <div class="invalid-feedback">Please provide a valid address</div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="form-group col-md-2" style="margin:0 auto">
                <input type="submit" name='r_update_btn' value="Update" class='form-control btn btn-warning'>

            </div>
        </div>

        <br>

    </form>
</div>
<?php } else {
        echo "<h4 style = 'color:red; text-align:center; margin:25%;'>Not Accessible</h4>";
    }
?>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/4.2.0/mdb.min.js"></script>
<script src="js/script.js"></script>