<?php

    if ( isset( $_GET['status'] ) ) {
        if ( $_GET['status'] == "mgs_dlt" ) {
            $dlt_id  = $_GET['id'];
            $dlt_mgs = $obj->mgs_dlt( $dlt_id );
        }
    }
    $message_data = $obj->display_message();
?>

<br>
<div class="card mb-4">
    <div class="card-header">
        <h5>

            <i class="fas fa-table mr-1"></i> Manage Comments:
        </h5>
        <div></div>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-bordered vertical_align" id="dataTable" width="100%" cellspacing="0">
                <thead>
                    <tr>
                        <th>S/N</th>
                        <th>Name</th>
                        <th>Roll</th>
                        <th>Reg No</th>
                        <?php if ( $_SESSION['admin_status'] == "Admin Officer" || $_SESSION['admin_status'] == "Admin-3" ) {?>
                        <th>Email</th>
                        <?php }?>

                        <th>Subject</th>
                        <th>Message</th>
                        <th>Date</th>
                        <?php if ( $_SESSION['admin_status'] == "Admin Officer" || $_SESSION['admin_status'] == "Admin-3" ) {?>
                        <th>Action</th>
                        <?php }?>
                    </tr>
                </thead>
                <tfoot>
                    <tr>
                        <th>S/N</th>
                        <th>Name</th>
                        <th>Roll</th>
                        <th>Reg No</th>
                        <?php if ( $_SESSION['admin_status'] == "Admin Officer" || $_SESSION['admin_status'] == "Admin-3" ) {?>
                        <th>Email</th>
                        <?php }?>
                        <th>Subject</th>
                        <th>Message</th>
                        <th>Date</th>
                        <?php if ( $_SESSION['admin_status'] == "Admin Officer" || $_SESSION['admin_status'] == "Admin-3" ) {?>
                        <th>Action</th>
                        <?php }?>
                    </tr>
                </tfoot>
                <tbody>
                    <?php $count = 1;while ( $info = mysqli_fetch_assoc( $message_data ) ) {?>
                    <tr>
                        <td><?php echo $count++; ?></td>
                        <td><?php echo $info['message_name']; ?></td>
                        <td><?php echo $info['message_roll']; ?></td>
                        <td><?php echo $info['message_reg']; ?></td>
                        <?php if ( $_SESSION['admin_status'] == "Admin Officer" || $_SESSION['admin_status'] == "Admin-3" ) {?>
                        <td><a
                                href="mailto:<?php echo $info['message_email']; ?>"><?php echo $info['message_email']; ?></a>
                        </td>
                        <?php }?>
                        <td style="text-align:left;white-space: normal;"><?php echo $info['message_subject']; ?></td>
                        <td style="text-align:justify;white-space: normal;"><?php echo $info['message_content']; ?></td>
                        <td><?php echo $info['message_date']; ?></td>

                        <?php if ( $_SESSION['admin_status'] == "Admin Officer" || $_SESSION['admin_status'] == "Admin-3" ) {?>
                        <td method='post'>
                            <a href="?status=mgs_dlt&&id=<?php echo $info['message_id']; ?>" class="btn btn-danger"
                                name="mgs_dlt_btn">Delete</a>
                        </td>
                        <?php }?>
                    </tr>
                    <?php }?>
                </tbody>
            </table>
        </div>
    </div>
</div>