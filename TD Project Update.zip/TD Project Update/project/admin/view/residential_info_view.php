<style>

</style>
<?php
    $per_page                   = 3;
    $pegi_count                 = 0;
    $r_item                     = array();
    $r_item_data                = $obj->residential_info();
    $r_numbers                  = mysqli_num_rows( $r_item_data );
    $r_item_display_pegi_number = ceil( $r_numbers / $per_page );

    $start        = 0;
    $current_page = 0;
    $Next         = 2;
    $Previous     = $r_item_display_pegi_number;

    if ( isset( $_GET['start'] ) ) {
        $start        = $_GET['start'];
        $current_page = $start;
        if ( $start == 1 ) {
            $Previous = $r_item_display_pegi_number;

        } else {
            $Previous = $start - 1;

        }
        if ( $start == $r_item_display_pegi_number ) {
            $Next = $r_item_display_pegi_number + 1;
        } else {
            $Next = $start + 1;
        }

        $start--;
        $start = $start * $per_page;

    }
?>
<?php
    if ( isset( $_POST['add_year'] ) ) {
        $result_year_status = $obj->r_add_year( $_POST );
    }

    if ( isset( $_POST['paid_btn'] ) ) {
        $result_paid_status = $obj->r_status_update( $_POST );

    }
    $r_data = $obj->pagi_residential_info( $start, $per_page );
    include_once 'residential_info/search_php_code.php';
?>

<br>
<div class="card mb-4">
    <div class="card-header">


        <h5>
            <i class="fas fa-table mr-1"></i> Residential Payment Status:
            <?php include_once 'search.php'?>
        </h5>

        <div></div>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-borde#b80606 vertical_align r_info_td_align" id="dataTable" width="100%"
                cellspacing="0">
                <thead>
                    <tr>
                        <th>S/N</th>
                        <th>ROLL</th>
                        <th>Reg No</th>
                        <th>YEAR</th>
                        <th>JAN</th>
                        <th>FEB</th>
                        <th>MAR</th>
                        <th>APR</th>
                        <th>MAY</th>
                        <th>JUN</th>
                        <th>JUL</th>
                        <th>AUG</th>
                        <th>SEP</th>
                        <th>OCT</th>
                        <th>NOV</th>
                        <th>DEC</th>
                        <!-- <th>STATUS</th> -->
                        <?php if ( $_SESSION['admin_status'] == "Admin Officer" || $_SESSION['admin_status'] == "Admin-1" ) {?>
                        <th style="border-right: 1px solid #dee2e6;">Action</th>
                        <?php }?>
                    </tr>
                </thead>
                <tfoot>

                    <th>S/N</th>
                    <th>ROLL</th>
                    <th>Reg No</th>
                    <th>YEAR</th>
                    <th>JAN</th>
                    <th>FEB</th>
                    <th>MAR</th>
                    <th>APR</th>
                    <th>MAY</th>
                    <th>JUN</th>
                    <th>JUL</th>
                    <th>AUG</th>
                    <th>SEP</th>
                    <th>OCT</th>
                    <th>NOV</th>
                    <th>DEC</th>
                    <!-- <th>STATUS</th> -->
                    <?php if ( $_SESSION['admin_status'] == "Admin Officer" || $_SESSION['admin_status'] == "Admin-1" ) {?>
                    <th style="border-right: 1px solid #dee2e6;">Action</th>
                    <?php }?>

                </tfoot>
                <?php

                if ( $check_search_data == 1 ) {?>
                <tbody>
                    <tr>
                        <td colspan=17 style="color:red;">No Result Available in The Table!!</td>
                    </tr>
                </tbody>
                <?php } else {?>
                <tbody>

                    <?php
                        if ( isset( $_GET['start'] ) ) {
                            $r_cout = $_GET['start'];
                            $cout   = ( $r_cout * $per_page ) - ( $per_page - 1 );

                        } else {
                            $cout = 1;
                        }

                            while ( $r_info = mysqli_fetch_assoc( $r_data ) ) {
                                $r_roll        = $r_info['non_r_roll'];
                                $r_reg         = $r_info['non_r_reg'];
                                $non_r_rm      = $r_info['non_r_rm'];
                                $r_unique_data = $obj->r_unique_info( $r_roll );
                                $items         = mysqli_num_rows( $r_unique_data );
                                $r_items       = 0;
                                $r_name        = str_replace( " ", "-", $r_info['non_r_name'] )

                            ?>

                    <tr>
                        <form action="" method="post">
                            <input type="hidden" name="add_year_roll" value="<?php echo $r_roll; ?>">
                            <td rowspan=<?php echo $items + 1 ?> style="border: 1px solid #dee2e6;">
                                <?php echo $cout++; ?></td>
                            <td rowspan=<?php echo $items - 1 ?> colspan=2 style="border-right: 1px solid #dee2e6;"><a
                                    href="mailto:<?php echo $r_info['non_r_email']; ?>"><img
                                        src="../uploads/<?php echo $r_info['non_r_img']; ?>" height="130px"
                                        width="110px" alt="Not Found" title="<?php echo $r_name; ?>" /></a></br><input
                                    style="margin-top:20px" type="submit" value="Add Year" name="add_year"
                                    class="btn btn-secondary"></td>
                        </form>



                    </tr>
                    <?php

                                while ( $data = mysqli_fetch_assoc( $r_unique_data ) ) {
                                    $check_paid = 0;
                                    $r_items++;
                                ?>
                    <tr>
                        <form action="" method="post">
                            <?php
                                if ( $r_items == ( $items - 1 ) ) {
                                            ?>
                            <td colspan=2 style="border-right: 1px solid #dee2e6;">
                                <?php echo "<b>Room No: </b>" . $non_r_rm; ?></td>

                            <?php
                                }
                                        ?>
                            <?php
    if ( $r_items == ( $items ) ) {
                ?>
                            <td style="font-weight:bold;border-right: 1px solid #dee2e6;"><?php echo $r_roll; ?></td>
                            <td style="font-weight:bold;border-right: 1px solid #dee2e6;"><?php echo $r_reg; ?></td>

                            <?php
                                }
                                        ?>
                            <td>
                                <?php echo $data['r_year']; ?>
                                <input type="hidden" value="<?php echo $data['r_id']; ?>" name="u_r_id">
                            </td>

                            <td style="vertical-align: middle;"><?php
                                                                    if ( $data['r_jan'] == 'Paid' ) {
                                                                                    echo '&#10004;' . 'Paid';
                                                                                $check_paid++;?>
                                <input type="hidden" value='P' name='r_jan'>

                                <?php
                                } else {?>
                                <input class="checkbox_size" type="checkbox" value='Paid' name='r_jan'> <del
                                    style='color:#b80606'>Paid</del>
                                <?php }

                                            ?>
                            </td>
                            <td><?php
                                    if ( $data['r_feb'] == 'Paid' ) {
                                                    echo '&#10004;' . 'Paid';
                                                    $check_paid++;
                                                ?>
                                <input type="hidden" value='P' name='r_feb'>
                                <?php
                                } else {?>
                                <input class="checkbox_size" type="checkbox" value='Paid' name='r_feb'> <del
                                    style='color:#b80606'>Paid</del>
                                <?php }

                                            ?>
                            </td>
                            <td><?php
                                    if ( $data['r_mar'] == 'Paid' ) {
                                                    echo '&#10004;' . 'Paid';
                                                    $check_paid++;
                                                ?>
                                <input type="hidden" value='P' name='r_mar'>
                                <?php
                                } else {?>
                                <input class="checkbox_size" type="checkbox" value='Paid' name='r_mar'> <del
                                    style='color:#b80606'>Paid</del>
                                <?php }

                                            ?>
                            </td>
                            <td><?php
                                    if ( $data['r_apr'] == 'Paid' ) {
                                                    echo '&#10004;' . 'Paid';
                                                    $check_paid++;
                                                ?>
                                <input type="hidden" value='P' name='r_apr'>
                                <?php
                                } else {?>
                                <input class="checkbox_size" type="checkbox" value='Paid' name='r_apr'> <del
                                    style='color:#b80606'>Paid</del>
                                <?php }

                                            ?>
                            </td>
                            <td><?php
                                    if ( $data['r_may'] == 'Paid' ) {
                                                    echo '&#10004;' . 'Paid';
                                                    $check_paid++;
                                                ?>
                                <input type="hidden" value='P' name='r_may'>
                                <?php
                                } else {?>
                                <input class="checkbox_size" type="checkbox" value='Paid' name='r_may'> <del
                                    style='color:#b80606'>Paid</del>
                                <?php }

                                            ?>
                            </td>
                            <td><?php
                                    if ( $data['r_jun'] == 'Paid' ) {
                                                    echo '&#10004;' . 'Paid';
                                                    $check_paid++;
                                                ?>
                                <input type="hidden" value='P' name='r_jun'>
                                <?php
                                } else {?>
                                <input class="checkbox_size" type="checkbox" value='Paid' name='r_jun'> <del
                                    style='color:#b80606'>Paid</del>
                                <?php }

                                            ?>
                            </td>
                            <td><?php
                                    if ( $data['r_jul'] == 'Paid' ) {
                                                    echo '&#10004;' . 'Paid';
                                                    $check_paid++;
                                                ?>
                                <input type="hidden" value='P' name='r_jul'>
                                <?php
                                } else {?>
                                <input class="checkbox_size" type="checkbox" value='Paid' name='r_jul'> <del
                                    style='color:#b80606'>Paid</del>
                                <?php }

                                            ?>
                            </td>
                            <td><?php
                                    if ( $data['r_aug'] == 'Paid' ) {
                                                    echo '&#10004;' . 'Paid';
                                                    $check_paid++;
                                                ?>
                                <input type="hidden" value='P' name='r_aug'>
                                <?php
                                } else {?>
                                <input class="checkbox_size" type="checkbox" value='Paid' name='r_aug'> <del
                                    style='color:#b80606'>Paid</del>
                                <?php }

                                            ?>
                            </td>
                            <td><?php
                                    if ( $data['r_sep'] == 'Paid' ) {
                                                    echo '&#10004;' . 'Paid';
                                                    $check_paid++;
                                                ?>
                                <input type="hidden" value='P' name='r_sep'>
                                <?php
                                } else {?>
                                <input class="checkbox_size" type="checkbox" value='Paid' name='r_sep'> <del
                                    style='color:#b80606'>Paid</del>
                                <?php }

                                            ?>
                            </td>
                            <td><?php
                                    if ( $data['r_oct'] == 'Paid' ) {
                                                    echo '&#10004;' . 'Paid';
                                                    $check_paid++;
                                                ?>
                                <input type="hidden" value='P' name='r_oct'>
                                <?php
                                } else {?>
                                <input class="checkbox_size" type="checkbox" value='Paid' name='r_oct'> <del
                                    style='color:#b80606'>Paid</del>
                                <?php }

                                            ?>
                            </td>
                            <td><?php
                                    if ( $data['r_nov'] == 'Paid' ) {
                                                    echo '&#10004;' . 'Paid';
                                                    $check_paid++;
                                                ?>
                                <input type="hidden" value='P' name='r_nov'>
                                <?php
                                } else {?>
                                <input class="checkbox_size" type="checkbox" value='Paid' name='r_nov'> <del
                                    style='color:#b80606'>Paid</del>
                                <?php }

                                            ?>
                            </td>
                            <td><?php
                                    if ( $data['r_dec'] == 'Paid' ) {
                                                    echo '&#10004;' . 'Paid';
                                                    $check_paid++;
                                                ?>
                                <input type="hidden" value='P' name='r_dec'>
                                <?php
                                } else {?>
                                <input class="checkbox_size" type="checkbox" value='Paid' name='r_dec'> <del
                                    style='color:#b80606'>Paid</del>
                                <?php }

                                            ?>
                            </td>
                            <?php if ( $check_paid == 12 ) {
                                                $obj->u_r_paid_status( $data['r_id'] );
                                            ?>
                            <!-- <td style = "color:blue;"><b>Completed</b></td> -->
                            <?php if ( $_SESSION['admin_status'] == "Admin Officer" || $_SESSION['admin_status'] == "Admin-1" ) {?>
                            <td style="border-right: 1px solid #dee2e6;">
                                <input type="submit" class="btn btn-danger" name="paid_btn" value="Update"
                                    disabled></input>
                            </td>
                            <?php }
                                            } else {
                                            ?>
                            <!-- <td style = "color:#b80606;"><b>Uncompleted</b></td> -->
                            <?php if ( $_SESSION['admin_status'] == "Admin Officer" || $_SESSION['admin_status'] == "Admin-1" ) {?>
                            <td style="border-right: 1px solid #dee2e6;">
                                <input type="submit" class="btn btn-danger" name="paid_btn" value="Update"></input>
                            </td>
                            <?php }
                                        }?>


                        </form>
                    </tr>
                    <?php
                        $check_paid = 0;

                                }
                            ?>

                    <?php }?>

                </tbody>

                <?php }?>
            </table>

        </div>
        <?php include_once 'residential_info/pegi.php';?>
    </div>

</div>