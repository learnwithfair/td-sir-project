<?php
    if ( isset( $_GET['status'] ) ) {
        if ( $_GET['status'] == "non_r_approve" ) {
            $non_r_approve_id = $_GET['id'];
            $approve_mgs      = $obj->non_r_approve( $non_r_approve_id );
            $r_approve_mgs    = $obj->put_r_info( $non_r_approve_id );
        }

    }
    if ( isset( $_GET['status'] ) ) {
        if ( $_GET['status'] == "non_r_dlt" ) {
            $non_r_dlt_id = $_GET['id'];
            $dlt_mgs      = $obj->non_r_delete( $non_r_dlt_id );
        }
    }
    $non_r_info = $obj->non_residential_info();
?>
<br>
<div class="card mb-4">
    <div class="card-header">
        <h5>
            <i class="fas fa-table mr-1"></i> Non Residential Info:
        </h5>
        <div></div>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-bordered vertical_align" id="dataTable" width="100%" cellspacing="0">
                <thead>
                    <tr>
                        <th>S/N</th>
                        <th>Name</th>
                        <th>Roll & Reg No</th>
                        <th>Description</th>
                        <th>Address</th>
                        <th>Image</th>
                        <th>Date</th>
                        <?php if ( $_SESSION['admin_status'] == "Admin Officer" || $_SESSION['admin_status'] == "Admin-2" ) {?>
                        <th>Action</th>
                        <?php }?>
                    </tr>
                </thead>
                <tfoot>
                    <tr>
                        <th>S/N</th>
                        <th>Name</th>
                        <th>Roll & Reg No</th>
                        <th>Description</th>
                        <th>Address</th>
                        <th>Image</th>
                        <th>Date</th>
                        <?php if ( $_SESSION['admin_status'] == "Admin Officer" || $_SESSION['admin_status'] == "Admin-2" ) {?>
                        <th>Action</th>
                        <?php }?>
                    </tr>
                </tfoot>
                <tbody>
                    <?php $count = 1;while ( $info = mysqli_fetch_assoc( $non_r_info ) ) {?>
                    <tr>
                        <td><?php echo $count++; ?></td>
                        <td style="text-align:left"><?php echo $info['non_r_name']; ?></td>
                        <td style="text-align:left">
                            <b>Roll No: </b><?php echo $info['non_r_roll']; ?>
                            <br>
                            <b>Reg No: </b><?php echo $info['non_r_reg']; ?>
                            <br>
                            <b>Session:
                            </b><?php echo $info['non_r_session'] . " - " . ( $info['non_r_session'] + 1 ); ?>


                        </td>





                        <td style="text-align:left">
                            <b>Room No: </b><?php echo $info['non_r_rm']; ?>
                            <br>
                            <b>Dept: </b><?php echo $info['non_r_dept']; ?>
                            <br>
                            <b>Father: </b><?php echo $info['non_r_fname']; ?>
                            <br>
                            <b>Mother: </b><?php echo $info['non_r_mname']; ?>

                        </td>

                        <td style="text-align:left;">
                            <?php
                            if ( $_SESSION['admin_status'] == "Admin Officer" || $_SESSION['admin_status'] == "Admin-2" ) {?>
                            <b>Email: </b><i><a
                                    href="mailto:<?php echo $info['non_r_email']; ?>"><?php echo $info['non_r_email']; ?></a></i>
                            <br>
                            <?php }?>
                            <b>Present: </b><i><?php echo $info['non_r_pre_address']; ?></i>
                            <br>
                            <b>Permanent: </b><i><?php echo $info['non_r_per_address']; ?></i>
                        </td>
                        <td><img src="../uploads/<?php echo $info['non_r_img']; ?>" height="110px" width="90px"
                                alt="Not Found"></td>
                        <td><?php echo $info['non_r_start']; ?></td>
                        <?php if ( $_SESSION['admin_status'] == "Admin Officer" || $_SESSION['admin_status'] == "Admin-2" ) {?>
                        <td method='post'>
                            <a href="?status=non_r_approve&&id=<?php echo $info['non_r_id']; ?>"
                                class="btn  btn-warning" name="non_r_approve_btn"
                                style="text-transform: none;">Approve</a>
                            <div></div><br>
                            <a href="?status=non_r_dlt&&id=<?php echo $info['non_r_id']; ?>" class="btn btn-danger"
                                name="non_r_dlt_btn">Delete</a>
                        </td>
                        <?php }?>

                    </tr>
                    <?php }?>
                </tbody>
            </table>
        </div>
    </div>
</div>