<?php
    $data = $obj->display_subadmin_list();
?>

<br>
<div class="card mb-4">
    <div class="card-header">
        <h5> <i class="fas fa-table mr-1"></i> Manage Admin:</h5>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-bordered vertical_align" id="dataTable" width="100%" cellspacing="0">
                <thead>
                    <tr>
                        <th>S/N</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Start Date</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tfoot>
                    <tr>
                        <th>S/N</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Start Date</th>
                        <th>Status</th>
                    </tr>
                </tfoot>
                <tbody>
                    <?php
                        $cout          = 1;
                        $admin_officer = 1;
                        $admin_1       = 1;
                        $admin_2       = 1;
                        $admin_3       = 1;
                        $admin_4       = 1;
                        $admin_5       = 1;
                        $admin_6       = 1;
                        $admin_7       = 1;
                        $admin_8       = 1;
                        $admin_9       = 1;
                    while ( $info = mysqli_fetch_assoc( $data ) ) {?>
                    <tr>
                        <td><?php echo $cout++; ?></td>
                        <td><?php echo $info['admin_name']; ?></td>
                        <td>
                            <a href="mailto:<?php echo $info['admin_email']; ?>">
                                <?php echo $info['admin_email']; ?>
                            </a>
                        </td>
                        <td><?php echo $info['admin_start']; ?></td>
                        <td><?php
                                if ( $info['admin_status'] == "Admin Officer" ) {?>
                            <b style="color:red;">*</b>
                            <?php echo $info['admin_status'] . " - (" . $admin_officer . ")";
                                        $admin_officer++;
                                    } elseif ( $info['admin_status'] == "Admin-1" ) {
                                        echo $info['admin_status'] . " (" . $admin_1 . ")";
                                        $admin_1++;
                                    } elseif ( $info['admin_status'] == "Admin-2" ) {
                                        echo $info['admin_status'] . " (" . $admin_2 . ")";
                                        $admin_2++;
                                    } elseif ( $info['admin_status'] == "Admin-3" ) {
                                        echo $info['admin_status'] . " (" . $admin_3 . ")";
                                        $admin_3++;
                                    } elseif ( $info['admin_status'] == "Admin-4" ) {
                                        echo $info['admin_status'] . " (" . $admin_4 . ")";
                                        $admin_4++;
                                    } elseif ( $info['admin_status'] == "Admin-5" ) {
                                        echo $info['admin_status'] . " (" . $admin_5 . ")";
                                        $admin_5++;
                                    } elseif ( $info['admin_status'] == "Admin-6" ) {
                                        echo $info['admin_status'] . " (" . $admin_6 . ")";
                                        $admin_6++;
                                    } elseif ( $info['admin_status'] == "Admin-7" ) {
                                        echo $info['admin_status'] . " (" . $admin_7 . ")";
                                        $admin_7++;
                                    } elseif ( $info['admin_status'] == "Admin-8" ) {
                                        echo $info['admin_status'] . " (" . $admin_8 . ")";
                                        $admin_8++;
                                    } elseif ( $info['admin_status'] == "Admin-9" ) {
                                        echo $info['admin_status'] . " (" . $admin_9 . ")";
                                        $admin_9++;
                                    } else {
                                        echo $info['admin_status'];
                                    }
                                    ?>
                        </td>
                    </tr>
                    <?php }?>
                </tbody>
            </table>
        </div>
    </div>
</div>