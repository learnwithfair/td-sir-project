<?php
$view = "residential_update";
include 'template.php';

?>