<?php
$view = "manage_message";
include 'template.php';

?>