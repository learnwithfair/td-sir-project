<?php
$view = "residential_info";
include 'template.php';

?>