<?php
$view = "manage_sub_admin";
include 'template.php';

?>