<?php
$view = "payment_query";
include 'template.php';

?>
