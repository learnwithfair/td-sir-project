<?php
$view = "sub_admin_list";
include 'template.php';

?>