<?php
class students_info {
    private $conn1;
    public function __CONSTRUCT() {
        $bdhost      = "localhost";
        $dbuser      = "root";
        $dbpassword  = "";
        $this->conn1 = mysqli_connect( $bdhost, $dbuser, $dbpassword, "student_info" );
        if ( !( $this->conn1 ) ) {
            die( "Database connection Error!!" );
        }
    }

    //display menu item
    public function display_menu_item() {
        $display_menu_item_query = "SELECT * FROM header_menu";
        $return_header_menu_mgs  = mysqli_query( $this->conn1, $display_menu_item_query );
        if ( isset( $return_header_menu_mgs ) ) {
            return $return_header_menu_mgs;
        }

    }

    //add registration data
    public function add_registration_data( $data ) {
        $non_r_name    = $data['non_r_name'];
        $non_r_roll    = $data['non_r_roll'];
        $non_r_reg     = $data['non_r_reg'];
        $non_r_session = $data['non_r_session'];
        $non_r_dept    = $data['non_r_dept'];
        $non_r_fname   = $data['non_r_fname'];
        $non_r_mname   = $data['non_r_mname'];
        $non_r_email   = $data['non_r_email'];
        $non_r_rm      = $data['non_r_rm'];
        $non_r_birth   = $data['non_r_birth'];
        $non_r_pre     = $data['non_r_pre'];
        $non_r_per     = $data['non_r_per'];

        $non_r_img_name     = $_FILES['non_r_img']['name'];
        $non_r_img_tmp_name = $_FILES['non_r_img']['tmp_name'];
        // Check Info
        $check_query     = "SELECT * FROM nonresidential_info WHERE (non_r_roll=$non_r_roll||non_r_reg=$non_r_reg)";
        $checking_result = mysqli_query( $this->conn1, $check_query );
        $result1         = mysqli_fetch_assoc( $checking_result );
        if ( isset( $result1 ) ) {
            return "You are already Registared.";
        } else {
            // Putting Info
            $non_r_query = "INSERT INTO nonresidential_info(non_r_name,non_r_roll,non_r_reg,non_r_session,non_r_dept,non_r_rm,non_r_fname,non_r_mname,non_r_email,non_r_birth,non_r_pre_address,non_r_per_address,non_r_start,non_r_img,non_r_status) VALUES('$non_r_name',$non_r_roll,$non_r_reg,$non_r_session,'$non_r_dept',$non_r_rm,'$non_r_fname','$non_r_mname','$non_r_email','$non_r_birth','$non_r_pre','$non_r_per',now(),'$non_r_img_name','Nonresidential')";
            $result      = mysqli_query( $this->conn1, $non_r_query );
            if ( $result ) {
                move_uploaded_file( $non_r_img_tmp_name, "./uploads/" . $non_r_img_name );
                return "Successfully registared.";
                // return $non_r_img_name;
            } else {
                return "Unsuccessfull !!";

            }
        }

    }

    // User Login
    public function user_login( $data ) {

        $non_r_roll = $data['non_r_roll'];
        $non_r_reg  = $data['non_r_reg'];

        // Check Info
        $check_query     = "SELECT * FROM nonresidential_info WHERE (non_r_roll=$non_r_roll&&non_r_reg=$non_r_reg)";
        $checking_result = mysqli_query( $this->conn1, $check_query );
        $result1         = mysqli_fetch_assoc( $checking_result );
        if ( isset( $result1 ) ) {
            session_start();
            $_SESSION['user_roll'] = $non_r_roll;
            $_SESSION['user_reg']  = $non_r_reg;

            header( "location:profile.php" );
            exit();

        } else {
            echo "<script>alert('Create an account then try again!!')</script>";
        }

    }

    // User Logout
    public function user_log_out() {
        session_start();
        unset( $_SESSION['user_roll'] );
        unset( $_SESSION['user_reg'] );
        header( "location: log_in.php" );
    }

    public function display_profile_info( $user_roll ) {
        $display_profile_query = "SELECT * FROM nonresidential_info WHERE non_r_roll=$user_roll";
        $result_data           = mysqli_query( $this->conn1, $display_profile_query );
        $data                  = mysqli_fetch_assoc( $result_data );
        return $data;
    }

    // Display Residential Unique Info
    public function r_unique_info( $r_roll ) {
        $display_r_query = "SELECT * FROM residential_info WHERE r_roll=$r_roll ORDER BY r_year ASC";
        $display_r_info  = mysqli_query( $this->conn1, $display_r_query );
        if ( isset( $display_r_info ) ) {
            return $display_r_info;
        }
    }

    // Delete Non Residential Info
    public function user_edit_profile( $data ) {

        $roll              = $_SESSION['user_roll'];
        $u_pre_address     = $data['u_pre_address'];
        $user_img_name     = $_FILES['user_img']['name'];
        $user_img_tmp_name = $_FILES['user_img']['tmp_name'];

        if ( empty( $user_img_name ) ) {

            // Update Present Address
            $user_pre_update_query = "UPDATE nonresidential_info SET non_r_pre_address='$u_pre_address' WHERE non_r_roll=$roll";
            $pre_result            = mysqli_query( $this->conn1, $user_pre_update_query );
            return "Image Changed unsuccessfully.";

        } else {
            // Get Image Name
            $search_r_img        = "SELECT * FROM nonresidential_info WHERE non_r_roll=$roll";
            $search_r_img_result = mysqli_query( $this->conn1, $search_r_img );
            $img_data            = mysqli_fetch_assoc( $search_r_img_result );

            if ( isset( $img_data ) ) {
                // Update Image Name
                $user_img_update_query = "UPDATE nonresidential_info SET non_r_img='$user_img_name',non_r_pre_address='$u_pre_address' WHERE non_r_roll=$roll";
                $result                = mysqli_query( $this->conn1, $user_img_update_query );
                if ( $result ) {
                    move_uploaded_file( $user_img_tmp_name, "uploads/" . $user_img_name );
                    $img = $img_data['non_r_img'];
                    if ( isset( $img ) ) {
                        unlink( "uploads/$img" );
                    }

                }
                return "Image Changed Successfully.";
            }
        }
    }

    // Put Messages
    public function put_comments( $data ) {
        $mgs_roll      = $data['mgs_roll'];
        $mgs_reg       = $data['mgs_reg'];
        $mgs_name      = $data['mgs_name'];
        $mgs_email     = $data['mgs_email'];
        $mgs_subject   = $data['mgs_subject'];
        $mgs_content   = $data['mgs_content'];
        $add_mgs_query = "INSERT INTO message_info(message_name,message_roll,message_reg,message_email,message_subject,message_content,message_date) VALUES('$mgs_name',$mgs_roll,$mgs_reg,'$mgs_email','$mgs_subject','$mgs_content',now())";
        $return_mgs    = mysqli_query( $this->conn1, $add_mgs_query );
        if ( $return_mgs ) {
            return "Send Message Successfully.";
        } else {
            return "Unsuccessful!!";
        }
    }

    // public function display_all_products() {
    //     $display_product_query = "SELECT * FROM add_product WHERE product_status=1 ORDER BY product_id DESC";
    //     $product_data              = mysqli_query( $this->conn1, $display_product_query );
    //     if($product_data){
    //         return $product_data;
    //     }
    // }

    // public function display_new_products($pegi_start,$pegi_end) {
    //     $display_product_query = "SELECT * FROM add_product WHERE product_status=1 ORDER BY product_id DESC LIMIT $pegi_start,$pegi_end";
    //     $product_data              = mysqli_query( $this->conn1, $display_product_query );
    //     if($product_data){
    //         return $product_data;
    //     }

    // }
    // public function display_feature_items_by_id($id) {
    //     $display_product_query = "SELECT * FROM add_product WHERE product_id=$id&&product_status=1";
    //     $product_data              = mysqli_query( $this->conn1, $display_product_query );
    //     $info = mysqli_fetch_assoc( $product_data );
    //     if($info){
    //         return $info;
    //     }

    // }

    // public function display_low_products($pegi_start,$pegi_end) {
    //     $display_product_query = "SELECT * FROM add_product WHERE product_status=1 ORDER BY product_price ASC LIMIT $pegi_start,$pegi_end";
    //     $product_data              = mysqli_query( $this->conn1, $display_product_query );
    //     if($product_data){
    //         return $product_data;
    //     }
    // }
    // public function display_high_products($pegi_start,$pegi_end) {
    //     $display_product_query = "SELECT * FROM add_product WHERE product_status=1 ORDER BY product_price DESC LIMIT $pegi_start,$pegi_end";
    //     $product_data              = mysqli_query( $this->conn1, $display_product_query );
    //     if($product_data){
    //         return $product_data;
    //     }
    // }
    // public function display_feature_items_details($id) {
    //     $display_feature_items_details_query = "SELECT * FROM add_product_img WHERE product_id=$id&&thumnail_status=1";
    //     $data              = mysqli_query( $this->conn1, $display_feature_items_details_query );
    //     $info1 = mysqli_fetch_assoc( $data );

    //     if($info1){
    //         return $info1;
    //     }
    // }
    // public function display_feature_img_by_id($id) {
    //     $display_feature_items_details_query = "SELECT * FROM add_product_img WHERE product_id=$id&&thumnail_status=0";
    //     $data              = mysqli_query( $this->conn1, $display_feature_items_details_query );

    //     if($data){
    //         return $data;
    //     }
    // }

    // public function display_menu_item() {
    //     $display_menu_item_query = "SELECT * FROM menu";
    //     $return_header_menu_mgs  = mysqli_query( $this->conn1, $display_menu_item_query );
    //     if ( isset( $return_header_menu_mgs ) ) {
    //         return $return_header_menu_mgs;
    //     }

    // }

    // public function submit_message( $data ) {
    //     $message_name            = $data['message_name'];
    //     $message_email           = $data['message_email'];
    //     $message_subject         = $data['message_subject'];
    //     $message_content         = $data['message_content'];
    //     $add_message_query       = "INSERT INTO message_info(message_name, message_email, message_subject, message_content, message_date) VALUES('$message_name','$message_email','$message_subject','$message_content',now())";
    //     $result_add_message      = mysqli_query( $this->conn1, $add_message_query );
    //     if ( $result_add_message ) {
    //         return "Message send successfully.";
    //     }
    //     else{
    //         return "Message is not send successfully.";
    //     }

    // }

}