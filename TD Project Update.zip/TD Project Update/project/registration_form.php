<?php include_once "includes/head.php";?>
<?php
    if ( isset( $_POST['reg_submit_btn'] ) ) {
        $add_reg_return_mgs = $obj1->add_registration_data( $_POST );
    }
?>



<body>
    <?php include_once "includes/header.php";?>

    <div class="card form_style2 mx-auto ">
        <div class="card-body p-4">
            <h3 class="card-title text-center pb-5">Registration Form</h3>
            <h6 style="color:red;"><?php if ( isset( $add_reg_return_mgs ) ) {echo $add_reg_return_mgs;}?></h6>
            <form class="needs-validation" action="" method="POST" novalidate enctype="multipart/form-data">
                <!-- name -->
                <div class="form-outline mb-4">
                    <input type="text" class="form-control" id="validationCustom01" name="non_r_name" value=""
                        required />
                    <label for="validationCustom01" class="form-label">Name</label>
                    <div class="valid-feedback">Looks good!</div>
                    <div class="invalid-feedback">Please provide a valid name.</div>
                </div>
                <!-- roll and registration -->
                <div class="row mb-4">
                    <div class="col">
                        <div class="form-outline">
                            <input type="number" id="form6Example1" class="form-control" id="validationCustom01"
                                value="" name="non_r_roll" required />
                            <label class="form-label" for="form6Example1">Roll number</label>
                            <div class="valid-feedback">Looks good!</div>
                            <div class="invalid-feedback">Please provide...</div>
                        </div>
                    </div>
                    <div class="col">
                        <div class="form-outline">
                            <input type="number" id="form6Example2" class="form-control" id="validationCustom01"
                                value="" name="non_r_reg" required />
                            <label class="form-label" for="form6Example2">Registration number</label>
                            <div class="valid-feedback">Looks good!</div>
                            <div class="invalid-feedback">Please provide...</div>
                        </div>
                    </div>
                </div>
                <!-- options -->





                <div class="col-12">
                    <label class="visually-hidden" for="inlineFormSelectPref">Preference</label>
                    <select class="select my-option-style" name="non_r_session" required>
                        <option value="">Select Session</option>
                        <?php for ( $i = 2010; $i < 2041; $i++ ) {?>
                        <option value="<?php echo $i; ?>"><?php echo $i . " - " . $i + 1; ?></option>
                        <?php }?>
                    </select>
                </div>

                <div class="row mb-4">
                    <div class="col">
                        <div class="form-outline">
                            <input type="number" id="form6Example1" class="form-control" id="validationCustom01"
                                value="" name="non_r_rm" />
                            <label class="form-label" for="form6Example1">Room No</label>
                            <div class="valid-feedback">Looks good!</div>
                            <div class="invalid-feedback">Please provide...</div>
                        </div>
                    </div>
                    <div class="col">
                        <div class="form-outline">
                            <input type="date" id="form6Example2" class="form-control" id="validationCustom01"
                                name="non_r_birth" value="" required />
                            <label class="form-label" for="form6Example2">Date of Birth</label>
                            <div class="valid-feedback">Looks good!</div>
                            <div class="invalid-feedback">Please provide...</div>
                        </div>
                    </div>
                </div>

                <?php
                    $departments = array( "CSE", "EEE", "ICE", "CE", "EECE", "URP", "GE", "Architectural", "Pharmacy", "Public Add", "STAT", "MATH", "Chemistry", "Physics", "SW", "HBS", "THM", "BBA", "ECO", "English", "Bangla" );
                ?>
                <div class="col-12">
                    <label class="visually-hidden" for="inlineFormSelectPref">Preference</label>
                    <select class="select my-option-style" name="non_r_dept" required>
                        <option value="">Select Department</option>
                        <?php
                            for ( $i = 0; $i < count( $departments ); $i++ ) {
                            ?>
                        <option value="<?php echo $departments[$i]; ?>"><?php echo $departments[$i]; ?></option>
                        <?php
                            }

                        ?>

                    </select>
                </div>





                <div class="row mb-4">
                    <div class="col">
                        <div class="form-outline">
                            <input type="text" id="form6Example1" class="form-control" id="validationCustom01" value=""
                                name="non_r_fname" required />
                            <label class="form-label" for="form6Example1">Father's name</label>
                            <div class="valid-feedback">Looks good!</div>
                            <div class="invalid-feedback">Please provide...</div>
                        </div>
                    </div>
                    <div class="col">
                        <div class="form-outline">
                            <input type="text" id="form6Example2" class="form-control" id="validationCustom01"
                                name="non_r_mname" value="" required />
                            <label class="form-label" for="form6Example2">Mother's name</label>
                            <div class="valid-feedback">Looks good!</div>
                            <div class="invalid-feedback">Please provide...</div>
                        </div>
                    </div>
                </div>

                <div class="form-outline mb-4">
                    <input type="text" class="form-control" id="validationCustom01" name="non_r_email" value=""
                        required />
                    <label for="validationCustom01" class="form-label">Email</label>
                    <div class="valid-feedback">Looks good!</div>
                    <div class="invalid-feedback">Please provide a valid email.</div>
                </div>


                <div class="row mb-4">
                    <div class="col">
                        <div class="form-outline">
                            <input type="text" class="form-control" id="validationCustom02" name="non_r_pre" value="" />
                            <label for="validationCustom02" class="form-label">Present address</label>
                            <div class="valid-feedback">Looks good!</div>
                            <div class="invalid-feedback">Please provide a valid address</div>
                        </div>
                    </div>
                    <div class="col">
                        <div class="form-outline">
                            <input type="text" class="form-control" id="validationCustom02" name="non_r_per" value=""
                                required />
                            <label for="validationCustom02" class="form-label">Permanent address</label>
                            <div class="valid-feedback">Looks good!</div>
                            <div class="invalid-feedback">Please provide a valid address</div>
                        </div>
                    </div>
                </div>




                <div class="form-outline mb-4">
                    <input type="file" class="form-control" id="validationCustom02" value="" name="non_r_img" required
                        accept="image/*" />
                    <label for="validationCustom02" class="form-label"></label>
                    <div class="valid-feedback">Looks good!</div>
                    <div class="invalid-feedback">Please provide a valid address</div>
                </div>
                <div class="form-check  mb-4">
                    <input class="form-check-input" type="checkbox" value="" id="invalidCheck" required />
                    <label class="form-check-label" for="invalidCheck">Agree to terms and conditions</label>
                    <div class="invalid-feedback">You must agree before submitting.</div>
                </div>
                <div class="col text-end">
                    <input class="btn btn-primary btn-block col-2" name="reg_submit_btn" type="submit"
                        value="SUBMIT"></input>

                </div>

            </form>
        </div>

        <div class="text-center">
            <p>
                If you are a member please login? <a href="log_in.php">Login</a>
            </p>
        </div>
    </div>

    <!-- footer -->
    <?php include_once "includes/footer.php";?>

    <!-- Footer -->

    <?php include_once 'includes/script.php';?>
</body>

</html>