<?php include_once "includes/head.php";?>


<body>
    <?php include_once "includes/header.php";?>

    <?php
        session_start();
        if ( isset( $_POST['user_log_out_btn'] ) ) {
            $obj1->user_log_out();
        }
        if ( isset( $_POST['user_img_btn'] ) ) {

            $obj1->user_edit_profile( $_POST );

        }

        if ( isset( $_SESSION['user_roll'] ) ) {
            $info = $obj1->display_profile_info( $_SESSION['user_roll'] );

        ?>
    <!-- ---------------------- -->
    <div class="profile_style" style="margin-top:20px;">
        <section class="h-100 gradient-custom-2">
            <div class="container py-5 h-100" style="margin-top: 20px ;">
                <div class="row d-flex justify-content-center align-items-center h-100">
                    <div class="col col-lg-9 col-xl-12">
                        <div class="card">

                            <div class="rounded-top text-white d-flex flex-row"
                                style="background-color: #000; height:200px;">

                                <div class="ms-4 mt-5 d-flex flex-column" style="width: 150px;height:220px;">

                                    <img src="uploads/<?php echo $info['non_r_img']; ?>" alt="Image Does not support"
                                        class="img-fluid img-thumbnail mt-4 mb-2"
                                        style="width: 150px; height: 170px; z-index: 1">


                                    <button type="button" class="btn btn-outline-dark" data-mdb-ripple-color="dark"
                                        style="z-index: 1;cursor: pointer:none;">

                                        Change Image

                                    </button>
                                    <form action="" method="post"
                                        style="margin-top:-30px;z-index: 2; opacity:0;cursor: pointer;"
                                        enctype="multipart/form-data">
                                        <input type="file" name="user_img" id="user_img" accept="image/*">
                                </div>
                                <div class="ms-3" style="margin-top: 100px;">
                                    <h5 style="text-transform:uppercase"><?php echo $info['non_r_name']; ?></h5>
                                    <p style="margin-bottom: 3px;"><b>Roll: </b><?php echo $info['non_r_roll']; ?></p>
                                    <p style=""><b>Reg No: </b><?php echo $info['non_r_reg']; ?></p>

                                </div>
                            </div>
                            <div class="p-4 text-black" style="background-color: #f8f9fa;">
                                <div class="d-flex justify-content-end text-center py-1">
                                    <div>
                                        <p class="small text-muted mb-0"><b>Name of the Department:</b>
                                            (<?php echo $info['non_r_dept']; ?>) </p>
                                    </div>

                                </div>
                                <div style="padding-bottom:20px"></div>


                            </div>
                            <div class="card-body p-4 text-black">
                                <div class="mb-5">
                                    <br>
                                    <h4>About</h4>
                                    <div class="p-4" style="background-color: #f8f9fa;">
                                        <table class="table " id="about_info">
                                            <thead>
                                            </thead>
                                            <tbody>
                                                <tr>
                                                    <th colspan=1>
                                                        <p class="font-italic mb-1"><b>Session </b>
                                                    </th>
                                                    <td colspan=5><b>:
                                                            &nbsp;</b><?php echo $info['non_r_session'] . " - " . $info['non_r_session'] + 1; ?>
                                                        </p>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <th colspan=1>
                                                        <p class="font-italic mb-1"><b>Date of Birth </b>
                                                    </th>
                                                    <td colspan=5><b>: &nbsp;</b><?php echo $info['non_r_birth']; ?></p>
                                                    </td>
                                                </tr>
                                                <?php
                                                    if ( $info['non_r_status'] == "Residential" ) {
                                                        ?>
                                                <tr>
                                                    <th colspan=1>
                                                        <p class="font-italic mb-1"><b>Room No </b>
                                                    </th>
                                                    <td colspan=5><b>: &nbsp;</b> <?php echo $info['non_r_rm']; ?></p>
                                                    </td>
                                                </tr>
                                                <?php
                                                    }
                                                    ?>
                                                <tr>
                                                    <th colspan=1>
                                                        <p class="font-italic mb-1"><b>Email </b>
                                                    </th>
                                                    <td colspan=5><b>: &nbsp;</b> <?php echo $info['non_r_email']; ?>
                                                        </p>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <th colspan=1>
                                                        <p class="font-italic mb-1"><b>Father's name </b>
                                                    </th>
                                                    <td colspan=5><b>: &nbsp;</b><?php echo $info['non_r_fname']; ?></p>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <th colspan=1>
                                                        <p class="font-italic mb-1"><b>Mother's name </b>
                                                    </th>
                                                    <td colspan=5><b>: &nbsp;</b><?php echo $info['non_r_mname']; ?>
                                                        </p>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <th colspan=1>
                                                        <p class="font-italic mb-0"><b>Present Address </b>
                                                    </th>
                                                    <td colspan=5><b>: &nbsp;</b><span class="input-icons"><input
                                                                class=""
                                                                style="background-color: #f8f9fa;padding:5px;width:95%; border: 2px solid #dee2e6; "
                                                                placeholder="Present Address" type="text"
                                                                value="<?php echo $info['non_r_pre_address']; ?>"
                                                                name="u_pre_address"><i class="fas fa-edit icon">
                                                            </i> </span></p>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <th colspan=1>
                                                        <p class="font-italic mb-0"><b>Permanent Address </b>
                                                    </th>
                                                    <td colspan=5><b>: &nbsp;</b>
                                                        <?php echo $info['non_r_per_address']; ?></p>
                                                    </td>
                                                </tr>
                                            </tbody>

                                        </table>
                                    </div>



                                    <?php
                                        if ( $info['non_r_status'] == "Residential" ) {
                                            ?>
                                    <br>
                                    <br>
                                    <h4>Payment Status</h4>
                                    <div class="p-4" style="background-color: #f8f9fa;overflow-x: auto; padding: 10px;">
                                        <table class="table table-align" style="">
                                            <thead>
                                                <th
                                                    style="border-left: 1px solid #dee2e6;border-top: 1px solid #dee2e6;">
                                                    YEAR
                                                </th>
                                                <th style="border-top: 1px solid #dee2e6;"><b>JAN</b></th>
                                                <th style="border-top: 1px solid #dee2e6;">FEB</th>
                                                <th style="border-top: 1px solid #dee2e6;">MAR</th>
                                                <th style="border-top: 1px solid #dee2e6;">APR</th>
                                                <th style="border-top: 1px solid #dee2e6;">MAY</th>
                                                <th style="border-top: 1px solid #dee2e6;">JUN</th>
                                                <th style="border-top: 1px solid #dee2e6;">JUL</th>
                                                <th style="border-top: 1px solid #dee2e6;">AUG</th>
                                                <th style="border-top: 1px solid #dee2e6;">SEP</th>
                                                <th style="border-top: 1px solid #dee2e6;">OCT</th>
                                                <th style="border-top: 1px solid #dee2e6;">NOV</th>
                                                <th
                                                    style="border-right: 1px solid #dee2e6;border-top: 1px solid #dee2e6;">
                                                    DEC
                                                </th>
                                            </thead>
                                            <tfoot>
                                                <th style="border-left: 1px solid #dee2e6;">YEAR</th>
                                                <th>JAN</th>
                                                <th>FEB</th>
                                                <th>MAR</th>
                                                <th>APR</th>
                                                <th>MAY</th>
                                                <th>JUN</th>
                                                <th>JUL</th>
                                                <th>AUG</th>
                                                <th>SEP</th>
                                                <th>OCT</th>
                                                <th>NOV</th>
                                                <th style="border-right: 1px solid #dee2e6;">DEC</th>
                                            </tfoot>
                                            <tbody>
                                                <?php
                                                    $payment_infos = $obj1->r_unique_info( $_SESSION['user_roll'] );
                                                            while ( $payment = mysqli_fetch_assoc( $payment_infos ) ) {
                                                            ?>
                                                <tr>
                                                    <th style="border-left: 1px solid #dee2e6;">
                                                        <?php echo $payment['r_year'] ?></th>
                                                    <td><?php if ( $payment['r_jan'] == "Paid" ) {echo '&#10004;' . $payment['r_jan'];} else {echo '<span style = font-size:10px;>&#x274C;</span>' . $payment['r_jan'];}?>
                                                    </td>
                                                    <td><?php if ( $payment['r_feb'] == "Paid" ) {echo '&#10004;' . $payment['r_feb'];} else {echo '<span style = font-size:10px;>&#x274C;</span>' . $payment['r_feb'];}?>
                                                    </td>
                                                    <td><?php if ( $payment['r_mar'] == "Paid" ) {echo '&#10004;' . $payment['r_mar'];} else {echo '<span style = font-size:10px;>&#x274C;</span>' . $payment['r_mar'];}?>
                                                    </td>
                                                    <td><?php if ( $payment['r_apr'] == "Paid" ) {echo '&#10004;' . $payment['r_apr'];} else {echo '<span style = font-size:10px;>&#x274C;</span>' . $payment['r_apr'];}?>
                                                    </td>
                                                    <td><?php if ( $payment['r_may'] == "Paid" ) {echo '&#10004;' . $payment['r_may'];} else {echo '<span style = font-size:10px;>&#x274C;</span>' . $payment['r_may'];}?>
                                                    </td>
                                                    <td><?php if ( $payment['r_jun'] == "Paid" ) {echo '&#10004;' . $payment['r_jun'];} else {echo '<span style = font-size:10px;>&#x274C;</span>' . $payment['r_jun'];}?>
                                                    </td>
                                                    <td><?php if ( $payment['r_jul'] == "Paid" ) {echo '&#10004;' . $payment['r_jul'];} else {echo '<span style = font-size:10px;>&#x274C;</span>' . $payment['r_jul'];}?>
                                                    </td>
                                                    <td><?php if ( $payment['r_aug'] == "Paid" ) {echo '&#10004;' . $payment['r_aug'];} else {echo '<span style = font-size:10px;>&#x274C;</span>' . $payment['r_aug'];}?>
                                                    </td>
                                                    <td><?php if ( $payment['r_sep'] == "Paid" ) {echo '&#10004;' . $payment['r_sep'];} else {echo '<span style = font-size:10px;>&#x274C;</span>' . $payment['r_sep'];}?>
                                                    </td>
                                                    <td><?php if ( $payment['r_oct'] == "Paid" ) {echo '&#10004;' . $payment['r_oct'];} else {echo '<span style = font-size:10px;>&#x274C;</span>' . $payment['r_oct'];}?>
                                                    </td>
                                                    <td><?php if ( $payment['r_nov'] == "Paid" ) {echo '&#10004;' . $payment['r_nov'];} else {echo '<span style = font-size:10px;>&#x274C;</span>' . $payment['r_nov'];}?>
                                                    </td>
                                                    <td style="border-right: 1px solid #dee2e6;">
                                                        <?php if ( $payment['r_dec'] == "Paid" ) {echo '&#10004;' . $payment['r_dec'];} else {echo '<span style = font-size:10px;>&#x274C;</span>' . $payment['r_dec'];}?>
                                                    </td>

                                                </tr>

                                                <?php

                                                            }
                                                        ?>
                                            </tbody>
                                        </table>
                                    </div>


                                    <?php

                                            }
                                        ?>

                                    <input class="btn btn-outline-dark" data-mdb-ripple-color="dark" style="z-index: 1"
                                        style="width:80px; " name="user_log_out_btn" type="submit"
                                        value="Log Out"></input>
                                    <input class="btn btn-outline-dark" data-mdb-ripple-color="dark" style="z-index: 1"
                                        style="width:80px; " name="user_img_btn" type="submit" value="Save"></input>
                                    <div class="d-flex justify-content-between align-items-center mb-4">

                                    </div>
                                    </form>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
    </div>
    </section>


    </div>


    <?php } else {
            header( "location: log_in.php" );
        }
    ?>





    <!-- footer -->
    <?php include_once "includes/footer.php";?>

    <!-- Footer -->

    <?php include_once 'includes/script.php';?>
</body>

</html>