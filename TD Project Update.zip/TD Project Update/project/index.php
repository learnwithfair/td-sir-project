<?php include_once "includes/head.php"?>

<body>
    <?php include_once "includes/header.php"?>


    <div>
        Container
    </div>


    <!-- footer -->
    <?php include_once "includes/footer.php"?>
    <!-- Footer -->


    <?php include_once 'includes/script.php';?>
</body>

</html>