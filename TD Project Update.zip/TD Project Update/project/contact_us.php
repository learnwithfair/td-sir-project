<?php include_once "includes/head.php"?>
<?php
    if ( isset( $_POST['mgs_submit_btn'] ) ) {
        $send_mgs = $obj1->put_comments( $_POST );
    }

?>

<body>

    <?php include_once "includes/header.php"?>


    <!-- ---------------------- -->
    <div class="container">
        <div class="row">
            <div class="col-md-6">
                <!-- <div class="card-margin p-2 pe-4 "> -->
                <div class="card mx-auto card-margin">
                    <div class="card-body p-5">
                        <div id="map">
                            <iframe
                                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3644.5047364624033!2d89.2762166143537!3d24.013260084601924!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x39fe84f0ec23a72b%3A0x775d6cd53cbdad8b!2sPabna%20University%20of%20Science%20and%20Technology!5e0!3m2!1sen!2sbd!4v1645125525754!5m2!1sen!2sbd"
                                width="100%" height="480" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
                        </div>
                        <!-- Section: Links -->
                        <?php include "includes/social_link.php";?>
                    </div>
                </div>

            </div>
            <div class="col-md-6">
                <div class="card mx-auto card-margin">
                    <div class="card-body p-5">
                        <h3 class="card-title text-center pb-5">Send us a Messages</h3>
                        <h5 style="color: red;">
                            <?php if ( isset( $send_mgs ) ) {echo $send_mgs;}?>
                        </h5>
                        <form action="" method="post">
                            <!-- Roll & Reg input -->
                            <div class="row mb-4">
                                <div class="col">
                                    <div class="form-outline">
                                        <input type="number" id="form4Example1" class="form-control" name="mgs_roll"
                                            required />
                                        <label class="form-label" for="form4Example1">Roll No</label>
                                    </div>
                                </div>
                                <div class="col">
                                    <div class="form-outline">
                                        <input type="number" id="form4Example1" class="form-control" name="mgs_reg"
                                            required />
                                        <label class="form-label" for="form4Example1">Reg No</label>
                                    </div>
                                </div>
                            </div>
                            <!-- Name input -->
                            <div class="form-outline mb-4">
                                <input type="text" id="form4Example1" class="form-control" name="mgs_name" required />
                                <label class="form-label" for="form4Example1">Name</label>
                            </div>


                            <!-- Email input -->
                            <div class="form-outline mb-4">
                                <input type="email" id="form4Example2" class="form-control" name="mgs_email" required />
                                <label class="form-label" for="form4Example2">Email address</label>
                            </div>

                            <!-- Subject input -->
                            <div class="form-outline mb-4">
                                <input type="text" id="form4Example1" class="form-control" name="mgs_subject"
                                    required />
                                <label class="form-label" for="form4Example1">Subject</label>
                            </div>

                            <!-- Message input -->
                            <div class="form-outline mb-4">
                                <textarea class="form-control" id="form4Example3" rows="4" required
                                    placeholder="Write your message here.." name="mgs_content"></textarea>
                                <label class="form-label" for="form4Example3">Message</label>
                            </div>
                            <br>


                            <!-- Submit button -->
                            <button type="submit" class="btn btn-primary btn-block mb-4" name="mgs_submit_btn">
                                Send
                            </button>
                        </form>
                    </div>
                </div>
                <br>
            </div>

        </div>
    </div>


    <!-- footer -->
    <?php include_once "includes/footer.php"?>
    <!-- Footer -->


    <?php include_once 'includes/script.php';?>
</body>

</html>